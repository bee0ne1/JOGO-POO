/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

import Auxiliar.Desenho;
import auxiliar.Posicao;

/**
 *
 * @author bedos
 */
public class Arrow extends Personagem{
    
    public Arrow(String sNomeImagePNG,String direction) {
        super(sNomeImagePNG);
        this.bMortal = true;
        this.direction = direction;
    }
    
    
}
