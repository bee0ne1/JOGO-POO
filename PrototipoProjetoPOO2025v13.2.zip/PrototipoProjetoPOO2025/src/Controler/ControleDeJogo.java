package Controler;


import Modelo.Arrow;
import Modelo.Chaser;
import Modelo.Personagem;

import Modelo.Hero;
import Modelo.ParedeAmarela;
import Modelo.Bomb;
import Modelo.Bullet;
import Modelo.Cadeado;
import Modelo.Portal;
import Modelo.Dust;
import Modelo.LancaChamas;
import Modelo.Fogo;
import Modelo.SaidaFase;
import auxiliar.Posicao;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

public class ControleDeJogo {
    private Tela tela;

    public ControleDeJogo(Tela tela) {
        this.tela = tela;
    }
    
    
    public void desenhaTudo(ArrayList<Personagem> e) {
        for (int i = 0; i < e.size(); i++) {
            e.get(i).autoDesenho();
        }
    }

    
    public void processaTudo(ArrayList<Personagem> umaFase) {
        Hero hero = (Hero) umaFase.get(0);
        Personagem pIesimoPersonagem;
        for (int i = 1; i < umaFase.size(); i++) {
            pIesimoPersonagem = umaFase.get(i);
            
            atirar(hero,pIesimoPersonagem); //funcao que faz o heroi atirar
            hero.coletar(pIesimoPersonagem,umaFase); // funcao que faz o heroi coletar itens
            movimentacaoChaser(hero,pIesimoPersonagem); // funcao que detecta o chaser
            movimentacaoArrow(pIesimoPersonagem,umaFase); //funcao que faz a movimentacao do arrow
            seEncostarMorre(hero,pIesimoPersonagem,umaFase); //funcao que verifica se o heroi enconstou em algo que o mata
            pIesimoPersonagem.mortePersonagem(); //funcao que verifica se o personagem morreu, e caso sim realiza a animacao
            lancaChamas(hero,pIesimoPersonagem,umaFase); //funcao que faz sair e entrar fogo do lancachamas
            teleporte(hero,pIesimoPersonagem,umaFase,tela); //funcao que realiza o teleportde
            verificaSaida(hero,pIesimoPersonagem,umaFase); //funcao que verifica se a saida esta aberta
            
        }
        /*para que o codigo das acoes do heroi sejam chamados uma vez por frame e nao pelo numero de vezes equivalente ao tamanho do for, 
        os metodos abaixo foram tirados do laço for */
        
        //funcao que verifica se o heroi morreu
        hero.mortePersonagem(); 
        terminouJogo(hero,umaFase);
    }
    

    /*Retorna true se a posicao pHero é válida para Hero com relacao a todos os personagens no array*/
    public boolean ehPosicaoValida(ArrayList<Personagem> umaFase, Hero hero, Posicao pHero) {
        Personagem pIesimoPersonagem;
        for (int i = 1; i < umaFase.size(); i++) {
            pIesimoPersonagem = umaFase.get(i);
            //caso for uma parede amarela ou uma bomba, ela devera ser empurrada
            if (pIesimoPersonagem instanceof ParedeAmarela || pIesimoPersonagem instanceof Bomb) {
                Posicao pPersonagem = pIesimoPersonagem.getPosicao();
                //caso a parede atenda todas as condicoes, ela sera empurrada, caso contrario nao sera empurrada 
                if (pIesimoPersonagem.getPosicao().igual(pHero)) {
                    if ("down".equals(hero.getDirection()) && !HaPersonagemAbaixo(pPersonagem,umaFase)) {
                        pIesimoPersonagem.moveDown();
                        return true;
                    }
                    else if ("up".equals(hero.getDirection()) && !HaPersonagemAcima(pPersonagem,umaFase)) {
                        pIesimoPersonagem.moveUp();
                        return true;
                    }
                    else if ("right".equals(hero.getDirection()) && !HaPersonagemNaDireita(pPersonagem,umaFase)) {
                        pIesimoPersonagem.moveRight();
                        return true;
                    }  
                    else if ("left".equals(hero.getDirection()) && !HaPersonagemNaEsquerda(pPersonagem,umaFase)) {
                        pIesimoPersonagem.moveLeft();
                        return true;
                    }
                    else {
                        return false;
                    }
                }  
            }
           //caso for qualquer outro objeto nao transponivel ela nao sera empurrada
            else if (!pIesimoPersonagem.isbTransponivel()) {
                if (pIesimoPersonagem.getPosicao().igual(pHero)) {
                      
                    if (pIesimoPersonagem instanceof Portal) {   
                        hero.voltaAUltimaPosicao();
                        hero.setTeleporteInicio(true);
                    }
                    else if (pIesimoPersonagem instanceof Cadeado && hero.getnChaves() > 0) {
                        umaFase.remove(pIesimoPersonagem);
                        hero.setnChaves(hero.getnChaves()-1);
                        System.out.println("Numero de chaves obtidas: " + hero.getnChaves());
                        return false;
                    }
                    else  {
                        return false; //retorna falso, pois o personagem vai voltar uma posicao pra tras
                    }
                }   
            }
                 
        }
        return true; //retorna true pois o personagem vai seguir a posicao que o player mandar
    }
    
    
    public boolean ColisaoBala(ArrayList<Personagem> umaFase, Bullet bala, Posicao pBala) {
        
        //deleta a bala caso ela ultrapasse a camera
        if (bala.getPosicao().getLinha() < tela.getCameraLinha() ||
            bala.getPosicao().getLinha() > tela.getCameraLinha()+15) {
            umaFase.remove(bala);
            return false;
        }
        
        for (int i = 1; i < umaFase.size(); i++) {
            Personagem pIesimoPersonagem = umaFase.get(i);   
           
            if (pIesimoPersonagem instanceof Bomb) { //verifica se a bala atinge alguma bomba
                if (pIesimoPersonagem.getPosicao().igual(pBala)) {
                    umaFase.remove(bala); 
                    Set<Posicao> bombasExplodidas = new HashSet<>();
                    Bomb b = (Bomb) pIesimoPersonagem;
                    b.explodir(this, umaFase, bombasExplodidas);
                    return false;
                }
            }
            else if((pIesimoPersonagem instanceof Dust || pIesimoPersonagem instanceof Chaser) && !pIesimoPersonagem.isMorrendo()) {
                if (pIesimoPersonagem.getPosicao().igual(pBala)) {
                    umaFase.remove(bala); 
                    pIesimoPersonagem.setMorrendo(true);
                    return false;
                }
            }
            else if (!pIesimoPersonagem.isbTransponivel() && !pIesimoPersonagem.isMorrendo()) { //verifica se a bala atinge alguma parede
                if (pIesimoPersonagem.getPosicao().igual(pBala)) {
                    umaFase.remove(bala); //caso a posicao da bala seja a mesma da parede, deleta a bala do cenario
                    return false;
                }
            }
             
        }
        return true; //retorna true pois a bala continua seguindo seu caminho
    }
    
    //funcao que verifica se o tiro inicial do heroi esta dentro de uma parede ou de uma bomba
    public boolean PosicaoInicialBala(ArrayList<Personagem> umaFase, Hero hero) {
        Personagem pIesimoPersonagem;
        int linhaHeroi = hero.getPosicao().getLinha() ;
        int colunaHeroi = hero.getPosicao().getColuna();
        
        for (int i = 1; i < umaFase.size(); i++) {
            
            pIesimoPersonagem = umaFase.get(i);
            int linhaP = pIesimoPersonagem.getPosicao().getLinha();
            int colunaP = pIesimoPersonagem.getPosicao().getColuna();
            
            if (   ("down".equals(hero.getDirection()) && linhaP == linhaHeroi+1 && colunaP == colunaHeroi) || 
                   ("up".equals(hero.getDirection()) && linhaP == linhaHeroi-1 && colunaP == colunaHeroi) ||
                   ("right".equals(hero.getDirection()) && linhaP == linhaHeroi && colunaP == colunaHeroi+1) ||
                   ("left".equals(hero.getDirection()) && linhaP == linhaHeroi && colunaP == colunaHeroi-1)) {
            
                
                //verifica se a bala vai spawnar em alguma bomba
                if (pIesimoPersonagem instanceof Bomb) {
                    Bomb b = (Bomb) pIesimoPersonagem;
                    Set<Posicao> bombasExplodidas = new HashSet<>();
                    b.explodir(this,umaFase,bombasExplodidas);
                    return false;
                }
                //verifica se a bala vai spawnar em uma poeira ou chaser
                else if ((pIesimoPersonagem instanceof Dust || pIesimoPersonagem instanceof Chaser) && !pIesimoPersonagem.isMorrendo()) {
                    pIesimoPersonagem.setMorrendo(true);
                    return false;
                }
                
                //verifica se a bala vai spawnar em alguma parede
                else if (!pIesimoPersonagem.isbTransponivel() && !pIesimoPersonagem.isMorrendo()) {
                    return false;
                }
            }            
        }
        return true;
    }
    
    
    public void movimentacaoChaser(Hero hero, Personagem pIesimoPersonagem) {
        if (pIesimoPersonagem instanceof Chaser) {
            Chaser chaser = (Chaser) pIesimoPersonagem;
            chaser.computeDirection(hero.getPosicao());
        }
    }
 
    public void atirar(Hero hero,Personagem pIesimoPersonagem) {
        if (pIesimoPersonagem instanceof Bullet) {
            hero.atirar(); //ativa a funcao da direcao do tiro
        }
    }
    
    public void seEncostarMorre(Hero hero,Personagem pIesimoPersonagem,ArrayList<Personagem> umaFase) {
        if (pIesimoPersonagem.isbMortal() && hero.getPosicao().igual(pIesimoPersonagem.getPosicao())) {
            hero.setMorrendo(true);
            umaFase.remove(pIesimoPersonagem);   
        } 
    }
    
     public void passouDeFase(Hero hero,ArrayList<Personagem> umaFase) {
        umaFase.clear();
        hero.importIcon("robbo_front.png");
        hero.setnBaterias(0);
        hero.setnChaves(0);
        hero.setTempoMorte(10);
        hero.setFase(hero.getFase()+1);
        
        if (hero.getFase() == 2) {
            hero.setnBolts(7);
            Fase fase2 = new Fase2();
            ArrayList<Personagem> novaFase = fase2.carregarFase(hero);
            umaFase.addAll(novaFase);
        }
        else if (hero.getFase() == 3) {
                hero.setnBolts(48);
                Fase3 fase3 = new Fase3();
                ArrayList<Personagem> novaFase = fase3.carregarFase(hero);
                umaFase.addAll(novaFase);
            }
        
            else if (hero.getFase() == 4) {
                hero.setnBolts(1);
                Fase4 fase4 = new Fase4();
                ArrayList<Personagem> novaFase = fase4.carregarFase(hero);
                umaFase.addAll(novaFase);
            }
            
            else if (hero.getFase() == 5) {
                hero.setnBolts(0);
                Fase5 fase5 = new Fase5();
                ArrayList<Personagem> novaFase = fase5.carregarFase(hero);
                umaFase.addAll(novaFase);
            }
        
        
        tela.atualizaCamera();
     }
     
     public void verificaSaida(Hero hero, Personagem pIesimoPersonagem,ArrayList<Personagem> umaFase) {
        if (pIesimoPersonagem instanceof SaidaFase) {
            if (hero.getnBolts() == 0) {
                pIesimoPersonagem.setbTransponivel(true);
                pIesimoPersonagem.importIcon("saida_aberta.png");
                
                if (hero.getPosicao().igual(pIesimoPersonagem.getPosicao())) 
                    passouDeFase(hero,umaFase);     
            }
        }
    }
    
    public void reseta(Hero hero,ArrayList<Personagem> umaFase) {
        umaFase.clear();
        hero.importIcon("robbo_front.png");
        hero.setnBaterias(0);
        hero.setnChaves(0);
        hero.setMorrendo(false);
        hero.setTempoMorte(10);
        
        if (hero.getnVidas() > 0) {
            hero.setnVidas(hero.getnVidas()-1);
            System.out.println("Vidas restantes: "+hero.getnVidas());
            
            if (hero.getFase() == 1) {
                hero.setnBolts(9);
                Fase fase1 = new Fase1();
                ArrayList<Personagem> novaFase = fase1.carregarFase(hero);
                umaFase.addAll(novaFase);   
            }
            else if (hero.getFase() == 2) {
                hero.setnBolts(7);
                Fase2 fase2 = new Fase2();
                ArrayList<Personagem> novaFase = fase2.carregarFase(hero);
                umaFase.addAll(novaFase);
            }
            else if (hero.getFase() == 3) {
                hero.setnBolts(48);
                Fase3 fase3 = new Fase3();
                ArrayList<Personagem> novaFase = fase3.carregarFase(hero);
                umaFase.addAll(novaFase);
            }
            
            else if (hero.getFase() == 4) {
                hero.setnBolts(1);
                Fase4 fase4 = new Fase4();
                ArrayList<Personagem> novaFase = fase4.carregarFase(hero);
                umaFase.addAll(novaFase);
            }
            
            else if (hero.getFase() == 5) {
                hero.setnBolts(0);
                Fase5 fase5 = new Fase5();
                ArrayList<Personagem> novaFase = fase5.carregarFase(hero);
                umaFase.addAll(novaFase);
            }
            
            
        }
        else {
            hero.setFase(1);
            hero.setnVidas(5);
            reseta(hero,umaFase);
        }
        tela.atualizaCamera();
    }
    
    public void terminouJogo(Hero hero,ArrayList<Personagem> umaFase) {
        if (hero.getFase() == 5) {
            int contadorChasers = 0;
            for (int i=1; i<umaFase.size(); i++) {
                if (umaFase.get(i) instanceof Chaser) {
                    contadorChasers++;
                }
            }
            if (contadorChasers == 0) {
                hero.setFase(6);
                umaFase.clear();
                Creditos fim = new Creditos();
                ArrayList<Personagem> novaFase = fim.carregarFase(hero);
                umaFase.addAll(novaFase);
            }
        }
    }
   
    
    public void teleporte(Hero hero, Personagem pIesimoPersonagem, ArrayList<Personagem> umaFase,Tela tela) {
        if (pIesimoPersonagem instanceof Portal) {
            Posicao pHero = hero.getPosicao();
            Posicao pPortal = pIesimoPersonagem.getPosicao();
            Portal portal = (Portal) pIesimoPersonagem;
            
            if (hero.isTeleporteInicio() &&
                ("up".equals(hero.getDirection()) && pPortal.igual(proximaPosicao(pHero, "up"))) ||
                ("down".equals(hero.getDirection()) && pPortal.igual(proximaPosicao(pHero, "down"))) ||
                ("left".equals(hero.getDirection()) && pPortal.igual(proximaPosicao(pHero, "left"))) ||
                ("right".equals(hero.getDirection()) && pPortal.igual(proximaPosicao(pHero, "right")))) { 
               
                portal.teleportarHeroi(this, hero, umaFase, tela);
                  
            }
            else if (hero.isTeleporteFim() &&
                    ("up".equals(hero.getDirection()) && pPortal.igual(proximaPosicao(pHero, "down"))) ||
                    ("down".equals(hero.getDirection()) && pPortal.igual(proximaPosicao(pHero, "up"))) ||
                    ("left".equals(hero.getDirection()) && pPortal.igual(proximaPosicao(pHero, "right"))) ||
                    ("right".equals(hero.getDirection()) && pPortal.igual(proximaPosicao(pHero, "left")))) {
                
                portal.teleportarHeroi(this, hero, umaFase, tela);
                
            } 
        }        
    }

    
    public void lancaChamas(Hero hero,Personagem pIesimoPersonagem, ArrayList<Personagem> umaFase) {
        if (pIesimoPersonagem instanceof LancaChamas) {
            LancaChamas lc = (LancaChamas) pIesimoPersonagem;
            if (lc.isSaindo()) {
                lc.saindoFogo(this, hero, umaFase);
            }
            if (lc.isEntrando()) {
                lc.entrandoFogo(umaFase);
            }
        }
    }
    
   public void movimentacaoArrow(Personagem pIesimoPersonagem, ArrayList<Personagem> umaFase) {
        if (pIesimoPersonagem instanceof Arrow) {
           Arrow arrow = (Arrow) pIesimoPersonagem;
           Posicao pArrow = pIesimoPersonagem.getPosicao();
           arrow.computeDirection(this, pArrow, umaFase);
        }
   }
    
    //funcoes que verificam se ha personagens ao redor de outro
    public boolean HaPersonagemAbaixo (Posicao p,ArrayList<Personagem> umaFase) {
        for (int i = 1; i < umaFase.size(); i++) {
            if (umaFase.get(i).getPosicao().getLinha() == p.getLinha()+1
                && umaFase.get(i).getPosicao().getColuna() == p.getColuna()) {
                return true;
            }
        }
        return false;
    }
    
    public boolean HaPersonagemAcima (Posicao p,ArrayList<Personagem> umaFase) {
        for (int i = 1; i < umaFase.size(); i++) {
            if (umaFase.get(i).getPosicao().getLinha() == p.getLinha()-1
                && umaFase.get(i).getPosicao().getColuna() == p.getColuna()) {
                return true;
            }
        }
        return false;
    }
    
    public boolean HaPersonagemNaDireita (Posicao p,ArrayList<Personagem> umaFase) {
        for (int i = 1; i < umaFase.size(); i++) {
            if (umaFase.get(i).getPosicao().getLinha() == p.getLinha()
                && umaFase.get(i).getPosicao().getColuna() == p.getColuna()+1) {
                return true;
            }
        }
        return false;
    }
    
    public boolean HaPersonagemNaEsquerda (Posicao p,ArrayList<Personagem> umaFase) {
        for (int i = 1; i < umaFase.size(); i++) {
            if (umaFase.get(i).getPosicao().getLinha() == p.getLinha()
                && umaFase.get(i).getPosicao().getColuna() == p.getColuna()-1) {
                return true;
            }
        }
        return false;
    }
    
    public boolean HaPersonagemDiagonalSE (Posicao p,ArrayList<Personagem> umaFase) {
        for (int i = 1; i < umaFase.size(); i++) {
            if (umaFase.get(i).getPosicao().getLinha() == p.getLinha()-1
                && umaFase.get(i).getPosicao().getColuna() == p.getColuna()-1) {
                return true;
            }
        }
        return false;  
    }
    
    public boolean HaPersonagemDiagonalSD (Posicao p,ArrayList<Personagem> umaFase) {
        for (int i = 1; i < umaFase.size(); i++) {
            if (umaFase.get(i).getPosicao().getLinha() == p.getLinha()-1
                && umaFase.get(i).getPosicao().getColuna() == p.getColuna()+1) {
                return true;
            }
        }
        return false;  
    }
    
    public boolean HaPersonagemDiagonalIE (Posicao p,ArrayList<Personagem> umaFase) {
        for (int i = 1; i < umaFase.size(); i++) {
            if (umaFase.get(i).getPosicao().getLinha() == p.getLinha()+1
                && umaFase.get(i).getPosicao().getColuna() == p.getColuna()-1) {
                return true;
            }
        }
        return false;  
    }
    
    public boolean HaPersonagemDiagonalID (Posicao p,ArrayList<Personagem> umaFase) {
        for (int i = 1; i < umaFase.size(); i++) {
            if (umaFase.get(i).getPosicao().getLinha() == p.getLinha()+1
                && umaFase.get(i).getPosicao().getColuna() == p.getColuna()+1) {
                return true;
            }
        }
        return false;
    }
    
    public boolean HaFogoNaProximaPosicao(Posicao p, String direcao, ArrayList<Personagem> umaFase) {
       Posicao proxP = proximaPosicao(p,direcao);
        for (int i = 1; i < umaFase.size(); i++) {
            if (proxP.igual(umaFase.get(i).getPosicao()) && umaFase.get(i) instanceof Fogo) {
                return true;
            }
        }
        return false;
    }
    
    //funcao que pega a proxima posicao de acordo com a direcao do personagem
    public Posicao proximaPosicao(Posicao atual, String direcao) {
        switch (direcao) {
            case "up": return new Posicao(atual.getLinha() - 1, atual.getColuna());
            case "down": return new Posicao(atual.getLinha() + 1, atual.getColuna());
            case "left": return new Posicao(atual.getLinha(), atual.getColuna() - 1);
            case "right": return new Posicao(atual.getLinha(), atual.getColuna() + 1);
            default: return atual;
        }
    }
    
}
