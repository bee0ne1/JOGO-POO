/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controler;

import Modelo.Hero;
import Modelo.Personagem;
import java.util.ArrayList;

/**
 *
 * @author bedos
 */
public class Fase3 extends Fase {

    @Override
    protected ArrayList<Personagem> carregarFase(Hero hero) {
        ArrayList<Personagem> fase3 = new ArrayList<>();

    fase3.add(hero);
    hero.setPosicao(1, 1);

    // Paredes básicas para estruturar corredores
    adicionarParedes(fase3, "blue_wall_h1.png", new int[][] {
        {0, 0}, {0, 2}, {0, 4}, {0, 6}, {0, 8}, {0, 10}, {0, 12}, 
        {10, 0}, {10, 2}, {10, 4}, {10, 6}, {10, 8}, {10, 10}, {10, 12}, {10, 14},
        {17, 0}, {17, 2}, {17, 4}, {17, 6}, {17, 8}, {17, 10}, {17, 12}, {17, 14},
        {30, 0}, {30, 2}, {30, 4}, {30, 6}, {30, 8}, {30, 10}, {30, 12}, {30, 14},
    });

    adicionarParedes(fase3, "blue_wall_h2.png", new int[][] {
        {0, 3}, {0, 5}, {0, 7}, {0, 9}, {0, 11}, {0, 13}, {0, 15},
        {10, 1}, {10, 3}, {10, 5}, {10, 7}, {10, 9}, {10, 11}, {10, 13}, {10, 15},
        {17, 1}, {17, 3}, {17, 5}, {17, 7}, {17, 9}, {17, 11}, {17, 13}, {17, 15},
        {30, 1}, {30, 3}, {30, 5}, {30, 7}, {30, 9}, {30, 11}, {30, 13}, {30, 15},
    });

    adicionarParedes(fase3, "blue_wall_v1.png", new int[][] {
        {0, 0},{2,0}, {5, 0}, {8,0},{11,0},{13,0}, {15, 0},{19, 0},{21, 0},{23, 0}, {25, 0},{27, 0},
        {23,7},{23,9},
        {0, 15},{2, 15}, {5, 15}, {8,15},{11,15},{13,15},{15, 15}, {19, 15},{21, 15},{23, 15}, {25, 15},{27, 15},
    });

    adicionarParedes(fase3, "blue_wall_v2.png", new int[][] {
        {1, 0},{3,0}, {6, 0}, {9,0},{12,0},{14,0},{16, 0},{20, 0},{22, 0},{24, 0}, {26, 0},{28, 0},
        {24,7},{24,9},
        {1, 15}, {3, 15},{6, 15},{9,15},{12,15}, {14,15},{16, 15}, {20, 15},{22, 15},{24, 15}, {26, 15},{28, 15},
    });
    
    adicionarParedes(fase3, "blue_ball.png", new int[][] {
        {0,1},{0,14},
        {1,13},
        {2, 13},
        {4, 0}, {4, 15},{4, 15},
        {7, 0},{7, 15},
        {24,8},
    });
    
    adicionarParedes(fase3, "purple_ball.png", new int[][] {
        {18,0},{18,15},
        {29,0},{29,15},
        
    });
    
    
    adicionarParedesAmarelas(fase3,"yellow_wall_horizontal.png",new int[][] {
        {2,4},{2,5},{2,6},{2,7},{2,8},{2,9},{2,10},
        {3,4},{3,5},{3,6},{3,7},{3,8},{3,9},{3,10},
        {4,4},{4,5},{4,6},{4,8},{4,9},{4,10},
        {5,4},{5,5},{5,9},{5,10},
        {6,4},{6,5},{6,6},{6,8},{6,9},{6,10},
        {7,4},{7,5},{7,6},{7,7},{7,8},{7,9},{7,10},
        {8,4},{8,5},{8,6},{8,7},{8,8},{8,9},{8,10},
    });

    // Lança-chamas com direções e delays variados
    adicionarLancaChamas(fase3, "down", 50, 11, 3);
    adicionarLancaChamas(fase3, "up", 15, 16, 5);
    adicionarLancaChamas(fase3, "down", 10, 11,7);
    adicionarLancaChamas(fase3, "up", 5, 16, 9);
    adicionarLancaChamas(fase3, "down", 3, 11,11);
    adicionarLancaChamas(fase3, "up", 1, 16, 13);
    

    adicionarBaterias(fase3, new int[][] {
        {9, 1},
    });

    adicionarChaves(fase3, new int[][] {
        {13, 14},
    });

    adicionarCadeados(fase3, new int[][] {
        {2, 14},
    });
    
    adicionarBombas(fase3, new int[][] {
        {2, 2},
        {8, 13},
        });
    
    adicionarBolts(fase3, new int[][] {
        {18, 1},{18, 2},{18, 3},{18, 4},{18, 5},{18, 6},{18, 7},{18, 8},{18, 9},{18, 10},{18, 11},{18, 12},{18, 13},{18, 14},
        {19, 1},{19, 14},
        {20, 1},{20, 14},
        {21, 1},{21, 14},
        {22, 1},{22, 14},
        {23, 1},{23, 14},
        {24, 1},{24, 14},
        {25, 1},{25, 14},
        {26, 1},{26, 14},
        {27, 1},{27, 14},
        {28, 1},{28, 14},
        {29, 1},{29, 2},{29, 3},{29, 4},{29, 5},{29, 6},{29, 7},{29, 8},{29, 9},{29, 10},{29, 11},{29, 12},{29, 13},{29, 14},
        });
    
    
    adicionarArrow(fase3,"right",28,7);
    
    adicionarVida(fase3, 1, 14);
    adicionarPortal(fase3, 5, 7, 1, 2);
    adicionarPortal(fase3, 14, 2, 2, 1);
    adicionarPortal(fase3, 1, 14, 3, 4);
    adicionarPortal(fase3, 23, 8, 4, 3);
    
    adicionarVida(fase3,23,6);
    
    adicionarSaida(fase3, 1, 7);

    return fase3;
    }
    
    
    
    
}
