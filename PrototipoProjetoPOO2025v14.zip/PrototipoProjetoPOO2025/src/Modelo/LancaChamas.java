/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;
import Controler.ControleDeJogo;
import auxiliar.Posicao;
import java.io.Serializable;
import java.util.List;
import java.util.ArrayList;
/**
 *
 * @author bedos
 */
public class LancaChamas extends Personagem implements Serializable{
    private boolean saindo = true;
    private boolean entrando = false;
    private int tempoAtivacao;
    ArrayList<Fogo> fogosDoLancaChamas = new ArrayList<>();
    
    
    
    public LancaChamas(String sNomeImagePNG, String direcaoLancaChamas,int tempo) {
        super(sNomeImagePNG);
        this.bMortal = false;
        this.bTransponivel = false;
        this.direction = direcaoLancaChamas;
        this.tempoAtivacao = tempo;
    }

    public boolean isSaindo() {
        return saindo;
    }

    public void setSaindo(boolean saindo) {
        this.saindo = saindo;
    }

    public boolean isEntrando() {
        return entrando;
    }

    public void setEntrando(boolean entrando) {
        this.entrando = entrando;
    }

    public int getTempoAtivacao() {
        return tempoAtivacao;
    } 
    
    public Fogo fogo(int index) {
        return fogosDoLancaChamas.get(index);
    }
    
    public int nFogos() {
        return fogosDoLancaChamas.size();
    }
    
    public void addFogo(Fogo fogo) {
        fogosDoLancaChamas.add(fogo);
    }
    
    public void saindoFogo(ControleDeJogo cj, Hero hero,ArrayList<Personagem> umaFase) {
        Fogo f = null;
        Posicao pF = null;
        int nFogo = -1;
        
        for (int i=0; i<nFogos();i++) {
            //faz uma verificacao se o fogo nao esta ativo, se nao coloque ele na posicao
            if (!fogo(i).isAtivo()) {
                f = fogo(i);
                pF = fogo(i).getPosicao();
                nFogo = i+1;
                break;
            }
        }
        //se nao for encontrado nenhum fogo, significa que todos estao ativos, por isso para de sair fogo e comeca a animacao de entrar
        if (f == null) {
            saindo = false;
            entrando = true;
        }
        
        //caso nao haja nada na posicao onde o primeiro fogo vai spawnar ao redor do lancachamas
        else if (("up".equals(direction) && !cj.HaPersonagemAcima(pPosicao,umaFase)) ||
                ("down".equals(direction) && !cj.HaPersonagemAbaixo(pPosicao,umaFase)) ||
                ("left".equals(direction) && !cj.HaPersonagemNaEsquerda(pPosicao,umaFase)) ||
                ("right".equals(direction) && !cj.HaPersonagemNaDireita(pPosicao,umaFase))) {
            
            if (f.getTempoSpawn() <= tempoAtivacao) {
                f.setTempoSpawn(f.getTempoSpawn()+1);
            }
            
            else {
                //verifica se o heroi esta aonde sai o primeiro fogo do lanca chamas, se sim ele morre
                if (hero.getPosicao().igual(cj.proximaPosicao(pPosicao,direction))) {
                    saindo = false;
                    hero.setMorrendo(true);
                }
                else {
                    f.setAtivo(true);
                    f.setTempoSpawn(0);
                    f.getPosicao().copia(cj.proximaPosicao(pPosicao, direction));
                    if ("up".equals(direction) || "down".equals(direction))
                        f.importIcon("fire1.png");
                    else
                        f.importIcon("fire3.png");
                }
            }
        }
       
        //caso ja tenha saido o primeiro fogo do lanca chamas, verifica onde o proximo fogo sera colocado
        else  {
            f.setPosicao(pPosicao.getLinha(),pPosicao.getColuna());
            while (cj.HaFogoNaProximaPosicao(pF,direction,umaFase)) {
                f.getPosicao().copia(cj.proximaPosicao(pF,direction));
            }
            
            //caso o heroi esteja na frente do proximo fogo
            if (hero.getPosicao().igual(cj.proximaPosicao(pF,direction))) {
                saindo = false;
                hero.setMorrendo(true);
            }
            
            //se tiver um personagem na frente cancela a animacao de sair fogo e inicia a de entrar
            else if (("up".equals(direction) && cj.HaPersonagemAcima(pF,umaFase)) ||
                    ("down".equals(direction) && cj.HaPersonagemAbaixo(pF,umaFase)) ||
                    ("left".equals(direction) && cj.HaPersonagemNaEsquerda(pF,umaFase)) ||
                    ("right".equals(direction) && cj.HaPersonagemNaDireita(pF,umaFase))) {
                saindo = false;
                entrando = true;
            }
            
            //se nao tiver nenhum personagem na frente, coloca um delay de spawn antes de o colocar
            else {    
                if (f.getTempoSpawn() < 1) {
                    f.setTempoSpawn(f.getTempoSpawn()+1);                   
                }
                else {
                    f.setAtivo(true);
                    f.setTempoSpawn(0);
                    f.getPosicao().copia(cj.proximaPosicao(pF,direction));
                    if ("up".equals(direction) || "down".equals(direction) ) {
                        if (nFogo%2 == 0) 
                            f.importIcon("fire2.png");
                        else
                            f.importIcon("fire1.png");
                    }
                    else {
                        if (nFogo%2 == 0) 
                            f.importIcon("fire4.png");
                        else
                            f.importIcon("fire3.png");
                    }
                }
            }
         
        }    
    }
    
    public void entrandoFogo(ArrayList<Personagem> umaFase) {
        Fogo f = null;
        Posicao pF = null;
        int nFogo = -1;
        for (int i = nFogos()-1; i>=0; i--) {
           if (fogo(i).getPosicao().getLinha() != 0 && fogo(i).getPosicao().getColuna() != 0) {
                f = fogo(i);
                pF = fogo(i).getPosicao();
                nFogo = i+1;
                break;
           }
        }
        if (f == null) {
            entrando = false;
            saindo = true;
        }
        else {
            if (f.getTempoSpawn() < 1) {
                f.setTempoSpawn(f.getTempoSpawn()+1);
            }
            else {
                f.importIcon("transparente.png");
                f.setAtivo(false);
                f.setPosicao(0, 0);
                f.setTempoSpawn(0);
            }
        }
        
    }
    
    
    
}
