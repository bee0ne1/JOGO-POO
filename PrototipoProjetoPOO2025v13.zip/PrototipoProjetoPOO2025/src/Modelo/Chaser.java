/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

import Auxiliar.Consts;
import Auxiliar.Desenho;
import auxiliar.Posicao;
import java.io.Serializable;

/**
 *
 * @author 2373891
 */
public class Chaser extends Personagem implements Serializable {
    private int delay = 10;

    public Chaser(String sNomeImagePNG) {
        super(sNomeImagePNG);
        this.bMortal = true;
    }

    public void computeDirection(Posicao heroPos) {
        int distLin = this.getPosicao().getLinha() - heroPos.getLinha(); 
        int distCol = this.getPosicao().getColuna() - heroPos.getColuna();
        
        if (distLin > 2)
            direction = "up";
        else if (distLin < -2) 
            direction = "down";
        else if (Math.abs(distLin) == 2 && distCol > 0)
            direction = "left";
        else if (Math.abs(distLin) == 2 && distCol < 0)
            direction = "right";
        else if(distCol == 0 && distLin == 2)
            direction = "up";
        else if (distCol == 0 && distLin == -2)
            direction = "down";
        else if(distLin == 0 && distCol == 2)
            direction = "left";
        else if(distLin == 0 && distCol == -2) {
            direction = "right";
        }  
    }

    public void autoDesenho() {
        
        //verifica que nao esta morrendo
        if (!this.isMorrendo()) {
            if (delay > 0) {
                delay--;
            }
            else {
                if ("left".equals(direction)) {
                    this.moveLeft();
                } else if("right".equals(direction)) {
                    this.moveRight();
                }
                else if ("up".equals(direction)) {
                    this.moveUp();
                } else if("down".equals(direction)) {
                    this.moveDown();
                }
            delay = 10;
            }
        }
    super.autoDesenho();
    }
    
    
    
    
    
    
    
}
