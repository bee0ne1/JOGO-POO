/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controler;

import Modelo.Hero;
import Modelo.Personagem;
import java.util.ArrayList;

/**
 *
 * @author bedos
 */
public class Creditos extends Fase {
    
    @Override
    protected ArrayList<Personagem> carregarFase(Hero hero) {
        ArrayList<Personagem> creditos = new ArrayList<>();
        
        
        creditos.add(hero);
        hero.setPosicao(6, 7);
        
        adicionarParedes(creditos, "F.png", new int[][] {
            {2, 5}, 
       
        });
        
        adicionarParedes(creditos, "I.png", new int[][] {
            {2, 7}, 
        
        });
        
        adicionarParedes(creditos, "M.png", new int[][] {
            {2, 9},
        
        });
        
        
        return creditos;
    }
}
