/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controler;
import Modelo.Personagem;
import Modelo.Hero;
import java.util.ArrayList;

/**
 *
 * @author bedos
 */

   public class Fase2 extends Fase {
    
    @Override
    public ArrayList<Personagem> carregarFase(Hero hero) {
        ArrayList<Personagem> fase2 = new ArrayList<>();
        
        fase2.add(hero);
        hero.setPosicao(23, 7); // Entrada clássica de Pac-Man

        // Paredes horizontais (pares de h1 e h2 lado a lado)
        adicionarParedes(fase2, "blue_wall_h1.png", new int[][] {
            {5, 1}, {5, 13},
            {10, 1}, {10, 13},
            {15, 1}, {15, 13},
            {20, 1},  {20, 13},
            {25, 1}, {25, 13},
        });
        
        adicionarParedes(fase2, "blue_wall_h2.png", new int[][] {
            
            {5, 2}, {5, 14},
            {10, 2}, {10, 14},
            {15, 2}, {15, 14},
            {20, 2}, {20, 14},
            {25, 2}, {25, 14},
            
        });

        // Paredes verticais (pares de v1 e v2 empilhadas)
        adicionarParedes(fase2, "blue_wall_v1.png", new int[][] {
            {3, 4}, {8, 4}, {13, 4}, {18, 4}, {23, 4}, {28, 4},
            {3, 11}, {8, 11}, {13, 11}, {18, 11}, {23, 11}, {28, 11}
        });

        adicionarParedes(fase2, "blue_wall_v2.png", new int[][] {
            {4, 4}, {9, 4}, {14, 4}, {19, 4}, {24, 4}, {29, 4},
            {4, 11}, {9, 11}, {14, 11}, {19, 11}, {24, 11}, {29, 11}
        });
        
        // Borda superior (linha 0) — horizontal
        adicionarParedes(fase2, "blue_wall_h1.png", new int[][] {
            {0, 0}, {0, 2}, {0, 4}, {0, 6}, {0, 8}, {0, 10}, {0, 12}, {0, 14}
        });
        adicionarParedes(fase2, "blue_wall_h2.png", new int[][] {
            {0, 1}, {0, 3}, {0, 5}, {0, 7}, {0, 9}, {0, 11}, {0, 13}, {0, 15}
        });

        // Borda inferior (linha 30) — horizontal
        adicionarParedes(fase2, "blue_wall_h1.png", new int[][] {
            {30, 0}, {30, 2}, {30, 4}, {30, 6}, {30, 8}, {30, 10}, {30, 12}, {30, 14}
        });
        adicionarParedes(fase2, "blue_wall_h2.png", new int[][] {
            {30, 1}, {30, 3}, {30, 5}, {30, 7}, {30, 9}, {30, 11}, {30, 13}, {30, 15}
        });

        // Borda esquerda (coluna 0) — vertical
        adicionarParedes(fase2, "blue_wall_v1.png", new int[][] {
            {1, 0}, {3, 0}, {5, 0}, {7, 0}, {9, 0}, {11, 0}, {13, 0}, {15, 0},
            {17, 0}, {19, 0}, {21, 0}, {23, 0}, {25, 0}, {27, 0}, 
        });
        adicionarParedes(fase2, "blue_wall_v2.png", new int[][] {
            {2, 0}, {4, 0}, {6, 0}, {8, 0}, {10, 0}, {12, 0}, {14, 0}, {16, 0},
            {18, 0}, {20, 0}, {22, 0}, {24, 0}, {26, 0}, {28, 0}
        });

        // Borda direita (coluna 15) — vertical
        adicionarParedes(fase2, "blue_wall_v1.png", new int[][] {
            {1, 15}, {3, 15}, {5, 15}, {7, 15}, {9, 15}, {11, 15}, {13, 15}, {15, 15},
            {17, 15}, {19, 15}, {21, 15}, {23, 15}, {25, 15}, {27, 15},
        });
        adicionarParedes(fase2, "blue_wall_v2.png", new int[][] {
            {2, 15}, {4, 15}, {6, 15}, {8, 15}, {10, 15}, {12, 15}, {14, 15}, {16, 15},
            {18, 15}, {20, 15}, {22, 15}, {24, 15}, {26, 15}, {28, 15}
        });
        
        adicionarParedes(fase2, "blue_ball.png", new int[][] {
            {29, 0}, {29, 15}
        });
        adicionarParedes(fase2, "purple_ball.png", new int[][] {
            {25, 3},{20, 3},{15, 3},{10, 3},{5, 3},
            {25, 12},{20, 12},{15, 12},{10, 12},{5, 12},
        });
        
        // Pontos colecionáveis estilo Pac-Man
        adicionarBolts(fase2, new int[][] {
            {3, 2}, {3, 13},
            {8, 2}, {8, 13},
            {13, 2}, {13, 13},
            {18, 2}, {18, 13},
            {23, 2}, {23, 13},
        });
        
        
        adicionarBaterias(fase2, new int[][] {
         {29, 8}, {1, 8}
        });
        
        
        adicionarBombas(fase2, new int[][] {
            {14, 8}
        });
        
        
        
        adicionarChaser(fase2,"red",22,2);
        adicionarChaser(fase2,"yellow",22,13);
        adicionarChaser(fase2,"blue",17,2);
        adicionarChaser(fase2,"pink",17,13);
        adicionarChaser(fase2,"red",12,2);
        adicionarChaser(fase2,"yellow",12,13);
        adicionarChaser(fase2,"blue",7,2);
        adicionarChaser(fase2,"pink",7,13);
        adicionarChaser(fase2,"red",2,2);
        adicionarChaser(fase2,"yellow",2,13);
        
        // Saída da fase no centro inferior
        adicionarSaida(fase2, 29, 7);

        return fase2;
    }
}

