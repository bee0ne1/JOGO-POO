/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;
import java.util.List;
import java.util.ArrayList;
/**
 *
 * @author bedos
 */
public class LancaChamas extends Personagem {
    private boolean saindo = true;
    private boolean entrando = false;
    private int tempoAtivacao;
    ArrayList<Fogo> fogosDoLancaChamas = new ArrayList<>();
    
    
    
    public LancaChamas(String sNomeImagePNG, String direcaoLancaChamas,int tempo) {
        super(sNomeImagePNG);
        this.bMortal = false;
        this.bTransponivel = false;
        this.direction = direcaoLancaChamas;
        this.tempoAtivacao = tempo;
    }

    public boolean isSaindo() {
        return saindo;
    }

    public void setSaindo(boolean saindo) {
        this.saindo = saindo;
    }

    public boolean isEntrando() {
        return entrando;
    }

    public void setEntrando(boolean entrando) {
        this.entrando = entrando;
    }

    public int getTempoAtivacao() {
        return tempoAtivacao;
    } 
    
    public Fogo fogo(int index) {
        return fogosDoLancaChamas.get(index);
    }
    
    public int nFogos() {
        return fogosDoLancaChamas.size();
    }
    
    public void addFogo(Fogo fogo) {
        fogosDoLancaChamas.add(fogo);
    }
    
    
}
