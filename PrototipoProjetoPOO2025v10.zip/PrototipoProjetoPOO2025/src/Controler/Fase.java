/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controler;

import Modelo.Battery;
import Modelo.Bolt;
import Modelo.Bomb;
import Modelo.Cadeado;
import Modelo.Chaser;
import Modelo.Chave;
import Modelo.Dust;
import Modelo.Explosao;
import Modelo.Fogo;
import Modelo.Hero;
import Modelo.LancaChamas;
import Modelo.Parede;
import Modelo.ParedeAmarela;
import Modelo.Personagem;
import Modelo.Portal;
import Modelo.SaidaFase;
import java.util.ArrayList;

/**
 *
 * @author bedos
 */
public abstract class Fase {
    
    protected abstract ArrayList<Personagem> carregarFase(Hero hero);
    
    protected void adicionarParedes(ArrayList<Personagem> fase, String imagem, int[][] posicoes) {
        for (int[] pos : posicoes) {
            Parede parede = new Parede(imagem);
            parede.setPosicao(pos[0], pos[1]);
            fase.add(parede);
        }
    }
    
    protected void adicionarParedesAmarelas(ArrayList<Personagem> fase, String imagem, int[][] posicoes) {
        for (int[] pos : posicoes) {
            ParedeAmarela paredeA = new ParedeAmarela(imagem);
            paredeA.setPosicao(pos[0], pos[1]);
            fase.add(paredeA);
        }
    }
    
    protected void adicionarBaterias(ArrayList<Personagem> fase, int[][] posicoes) {
        for (int[] pos : posicoes) {
            Battery bateria = new Battery("battery.png");
            bateria.setPosicao(pos[0], pos[1]);
            fase.add(bateria);
        }
    }
    
    protected void adicionarBolts(ArrayList<Personagem> fase, int[][] posicoes) {
        for (int[] pos : posicoes) {
            Bolt bolt = new Bolt("bolt.png");
            bolt.setPosicao(pos[0], pos[1]);
            fase.add(bolt);
        }
    }
    protected void adicionarDusts(ArrayList<Personagem> fase, int[][] posicoes) {
        for (int[] pos : posicoes) {
            Dust dust = new Dust("dust.png");
            dust.setPosicao(pos[0], pos[1]);
            fase.add(dust);
        }
    }
    
    
    protected void adicionarChaves(ArrayList<Personagem> fase, int[][] posicoes) {
        for (int[] pos : posicoes) {
            Chave chave = new Chave("key.png");
            chave.setPosicao(pos[0], pos[1]);
            fase.add(chave);
        }
    }
    
    protected void adicionarCadeados(ArrayList<Personagem> fase, int[][] posicoes) {
        for (int[] pos : posicoes) {
            Cadeado lock = new Cadeado("lock.png");
            lock.setPosicao(pos[0], pos[1]);
            fase.add(lock);
        }
    }
    
    
    protected void adicionarLancaChamas(ArrayList<Personagem> fase,String direcao, int linha, int coluna) {
        LancaChamas lc = null;
        if ("up".equals(direcao)) 
            lc = new LancaChamas("flamethrower_up.png",direcao);
        else if ("down".equals(direcao)) 
            lc = new LancaChamas("flamethrower_down.png",direcao);
        else if ("left".equals(direcao)) 
            lc = new LancaChamas("flamethrower_left.png",direcao);
        else if ("right".equals(direcao)) 
            lc = new LancaChamas("flamethrower_right.png",direcao);
        
        lc.setPosicao(linha, coluna);
        fase.add(lc);
        for (int i = 0; i < 9; i++) {
            Fogo fogo = new Fogo("transparente.png");
            fogo.setPosicao(0, 0);
            lc.addFogo(fogo);
            fase.add(fogo);
        }
            
    }
    
    //PARA CADA BOMBA ADICIONE 9 EXPLOSOES
    protected void adicionarBombas(ArrayList<Personagem> fase, int[][] posicoes) {
        for (int[] pos : posicoes) {
            Bomb bomba = new Bomb("bomb.png");
            bomba.setPosicao(pos[0], pos[1]);
            fase.add(bomba);
            for (int i = 0; i < 9; i++) {
                Explosao e = new Explosao("transparente.png");
                e.setPosicao(0, 0);
                bomba.addExplosao(e);
                fase.add(e);
            }
        }
    }
    
    protected void adicionarPortal(ArrayList<Personagem> fase, int linha, int coluna,int nPortal, int nConexao) {
        Portal portal = new Portal("portal.png",nPortal,nConexao);
        portal.setPosicao(linha, coluna);
        fase.add(portal);
    }
    
    protected void adicionarChaser(ArrayList<Personagem> fase,String cor, int linha, int coluna) {
        Chaser chaser = null;
        if (cor == "pink") 
            chaser = new Chaser("pink.png");
        else if (cor == "red") 
            chaser = new Chaser("red.png");
        else if (cor == "blue")
            chaser = new Chaser("blue.png");
        else if (cor == "yellow")
            chaser = new Chaser("yellow.png");
        
        chaser.setPosicao(linha,coluna);
        fase.add(chaser);
    }
            
    protected void adicionarSaida(ArrayList<Personagem> fase, int linha, int coluna) {
        SaidaFase saida = new SaidaFase("saida.png");
        saida.setPosicao(linha, coluna);
        fase.add(saida);
    }
    
    
}
