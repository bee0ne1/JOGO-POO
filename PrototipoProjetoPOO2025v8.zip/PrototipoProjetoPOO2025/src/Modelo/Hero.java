 package Modelo;

import Auxiliar.Consts;
import Auxiliar.Desenho;
import Controler.ControleDeJogo;
import Controler.Tela;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.io.IOException;
import java.io.Serializable;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class Hero extends Personagem implements Serializable{
    private Bullet balaHeroi = new Bullet("bullet.png");
    private int nVidas = 3;
    private int nBaterias = 0;
    private int nBolts = 9;
    private int nChaves = 0;
    private int fase = 1;
    private boolean teleporteInicio = false;
    private boolean teleporteFim = false;
    private int tempoTeleporte = 10;
    
    
    public Hero(String sNomeImagePNG) {
        super(sNomeImagePNG);
    }

    public void voltaAUltimaPosicao(){
        this.pPosicao.volta();
    }
    
    @Override
    public boolean setPosicao(int linha, int coluna){
        if(this.pPosicao.setPosicao(linha, coluna)){
            if (!Desenho.acessoATelaDoJogo().ehPosicaoValida(this.getPosicao(),this)) {
                this.voltaAUltimaPosicao();
            }
            return true;
        }
        return false;       
    }

    /*TO-DO: este metodo pode ser interessante a todos os personagens que se movem*/
    private boolean validaPosicao(){
        if (!Desenho.acessoATelaDoJogo().ehPosicaoValida(this.getPosicao(),this)) {
            this.voltaAUltimaPosicao();
            return false;
        }
        return true;       
    }
    
    @Override
    public boolean moveUp() {
        if(super.moveUp())
            return validaPosicao();
            
        return false;
    }

    @Override
    public boolean moveDown() {
        if(super.moveDown())
            return validaPosicao();
        return false;
    }

    @Override
    public boolean moveRight() {
        if(super.moveRight())
            return validaPosicao();
        return false;
    }

    @Override
    public boolean moveLeft() {
        if(super.moveLeft())
            return validaPosicao();
        return false;
    }    

    public Bullet getBalaHeroi() {
        return balaHeroi;
    }
   

    public int getnVidas() {
        return nVidas;
    }

    public int getnBaterias() {
        return nBaterias;
    }

    public int getnBolts() {
        return nBolts;
    }
    
    
    public void setnVidas(int nVidas) {
        this.nVidas = nVidas;
    }

    public void setnBaterias(int nBaterias) {
        this.nBaterias = nBaterias;
    }

    public void setnBolts(int nBolts) {
        this.nBolts = nBolts;
    }

    public int getnChaves() {
        return nChaves;
    }

    public void setnChaves(int nChaves) {
        this.nChaves = nChaves;
    }

    public int getFase() {
        return fase;
    }

    public void setFase(int fase) {
        this.fase = fase;
    }

    public boolean isTeleporteInicio() {
        return teleporteInicio;
    }

    public void setTeleporteInicio(boolean teleporteInicio) {
        this.teleporteInicio = teleporteInicio;
    }

    public boolean isTeleporteFim() {
        return teleporteFim;
    }

    public void setTeleporteFim(boolean teleporteFim) {
        this.teleporteFim = teleporteFim;
    }

   
    public int getTempoTeleporte() {
        return tempoTeleporte;
    }

    public void setTempoTeleporte(int tempoTeleporte) {
        this.tempoTeleporte = tempoTeleporte;
    }
    
    
    
    
}
