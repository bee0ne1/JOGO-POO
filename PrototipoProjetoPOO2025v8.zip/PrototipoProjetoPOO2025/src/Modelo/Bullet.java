/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

import Auxiliar.Consts;
import Auxiliar.Desenho;
import Controler.ControleDeJogo;
import Controler.Tela;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.io.IOException;
import java.io.Serializable;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JPanel;

/**
 *
 * @author bedos
 */
public class Bullet extends Personagem{
    
    public Bullet(String sNomeImagePNG) {
        super(sNomeImagePNG);
    }
    
    @Override
    public boolean moveUp() {
        if(super.moveUp())
            return validaPosicao();
            
        return false;
    }

    @Override
    public boolean moveDown() {
        if(super.moveDown())
            return validaPosicao();
        return false;
    }

    @Override
    public boolean moveRight() {
        if(super.moveRight())
            return validaPosicao();
        return false;
    }

    @Override
    public boolean moveLeft() {
        if(super.moveLeft())
            return validaPosicao();
        return false;
    }    
    
    
    public void direcaoBullet(Hero hero) {
        if (this.getPosicao().getLinha() > hero.getPosicao().getLinha()) {
            this.moveDown();
        } 
        else if (this.getPosicao().getLinha() < hero.getPosicao().getLinha()) {
            this.moveUp();
        }
        else if (this.getPosicao().getColuna() < hero.getPosicao().getColuna()) {
            this.moveLeft();
        } 
        else if (this.getPosicao().getColuna() > hero.getPosicao().getColuna()) {
            this.moveRight();
        }
    }
    
    public void voltaAUltimaPosicao(){
        this.pPosicao.volta();
    }
    
    private boolean validaPosicao(){
        if (!Desenho.acessoATelaDoJogo().ColisaoBala(this.getPosicao())) {
            return false;
        }
        return true;       
    }
    
    
}
