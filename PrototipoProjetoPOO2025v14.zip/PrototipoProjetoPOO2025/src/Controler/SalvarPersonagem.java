/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controler;

import java.io.*;
import java.util.zip.*;
import Modelo.Personagem;
import Modelo.Arrow;
import Modelo.Battery;
import Modelo.BichinhoVaiVemHorizontal;
import Modelo.Bolt;
import Modelo.Bomb;
import Modelo.Cadeado;
import Modelo.Chaser;
import Modelo.Chave;
import Modelo.Dust;
import Modelo.Hero;
import Modelo.LancaChamas;
import Modelo.Life;
import Modelo.Parede;
import Modelo.ParedeAmarela;
/**
 *
 * @author bedos
 */
public class SalvarPersonagem {
    
    public void listaDePersonagens() {
        Personagem robbo = new Hero("robbo_front.png");
        salvarPersonagemComoZip(robbo, "personagens/robbo.zip");
        Personagem parede_azul_h1 = new Parede("blue_wall_h1.png");
        salvarPersonagemComoZip(parede_azul_h1, "personagens/parede_azul_h1.zip");
        Personagem parede_azul_h2 = new Parede("blue_wall_h2.png");
        salvarPersonagemComoZip(parede_azul_h2, "personagens/parede_azul_h2.zip");
        Personagem parede_azul_v1 = new Parede("blue_wall_v1.png");
        salvarPersonagemComoZip(parede_azul_v1, "personagens/parede_azul_v1.zip");
        Personagem parede_azul_v2 = new Parede("blue_wall_v2.png");
        salvarPersonagemComoZip(parede_azul_v2, "personagens/parede_azul_v2.zip");
        Personagem bola_azul = new Parede("blue_ball.png");
        SalvarPersonagem.salvarPersonagemComoZip(bola_azul, "personagens/bola_azul.zip");
        Personagem bola_roxa = new Parede("purple_ball.png");
        SalvarPersonagem.salvarPersonagemComoZip(bola_roxa, "personagens/bola_roxa.zip");
        Personagem parede_amarela_h = new ParedeAmarela("yellow_wall_horizontal.png");
        SalvarPersonagem.salvarPersonagemComoZip(parede_amarela_h, "personagens/parede_amarela_h.zip");
        Personagem parede_amarela_v = new ParedeAmarela("yellow_wall_vertical.png");
        SalvarPersonagem.salvarPersonagemComoZip(parede_amarela_v, "personagens/parede_amarela_v.zip");
        Personagem poeira = new Dust("dust.png");
        SalvarPersonagem.salvarPersonagemComoZip(poeira, "personagens/poeira.zip");
        Personagem chave = new Chave("key.png");
        SalvarPersonagem.salvarPersonagemComoZip(chave, "personagens/chave.zip");
        Personagem cadeado = new Cadeado("lock.png");
        SalvarPersonagem.salvarPersonagemComoZip(cadeado, "personagens/cadeado.zip");
        Personagem bateria = new Battery("battery.png");
        SalvarPersonagem.salvarPersonagemComoZip(bateria, "personagens/bateria.zip");
        Personagem bolt = new Bolt("bolt.png");
        SalvarPersonagem.salvarPersonagemComoZip(bolt, "personagens/bolt.zip");
        Personagem bomba = new Bomb("bomb.png");
        SalvarPersonagem.salvarPersonagemComoZip(bomba, "personagens/bomba.zip");
        Personagem fantasma_vermelho = new Chaser("red.png");
        SalvarPersonagem.salvarPersonagemComoZip(fantasma_vermelho, "personagens/fantasma_vermelho.zip");
        Personagem fantasma_amarelo = new Chaser("yellow.png");
        SalvarPersonagem.salvarPersonagemComoZip(fantasma_amarelo, "personagens/fantasma_amarelo.zip");
        Personagem fantasma_rosa = new Chaser("pink.png");
        SalvarPersonagem.salvarPersonagemComoZip(fantasma_rosa, "personagens/fantasma_rosa.zip");
        Personagem fantasma_azul = new Chaser("blue.png");
        SalvarPersonagem.salvarPersonagemComoZip(fantasma_azul, "personagens/fantasma_azul.zip");
        Personagem metroid = new Chaser("metroid.png");
        SalvarPersonagem.salvarPersonagemComoZip(metroid, "personagens/metroid.zip");
        Personagem vida = new Life("vida.png");
        SalvarPersonagem.salvarPersonagemComoZip(vida, "personagens/vida.zip");

    }
    
    
    public static void salvarPersonagemComoZip(Personagem p, String caminhoZip) {
        try {
            // serializa o personagem para um ByteArray
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            ObjectOutputStream oos = new ObjectOutputStream(baos);
            oos.writeObject(p);
            oos.close();
            byte[] bytesPersonagem = baos.toByteArray();

            //cria o zip
            FileOutputStream fos = new FileOutputStream(caminhoZip);
            ZipOutputStream zos = new ZipOutputStream(fos);
            ZipEntry entry = new ZipEntry("personagem.ser");
            zos.putNextEntry(entry);
            zos.write(bytesPersonagem);
            zos.closeEntry();
            zos.close();

            System.out.println("Personagem salvo em: " + caminhoZip);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
}
