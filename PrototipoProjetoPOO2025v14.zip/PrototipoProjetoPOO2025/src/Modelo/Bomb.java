/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;
import Controler.ControleDeJogo;
import auxiliar.Posicao;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Set;
/**
 *
 * @author bedos
 */
public class Bomb extends Personagem implements Serializable {
   ArrayList<Explosao> explosoes = new ArrayList<>();
    
    public Bomb(String sNomeImagePNG) {
        super(sNomeImagePNG);
    }
    
    public Explosao explosao(int index) {
        return explosoes.get(index);
    }

    public void addExplosao(Explosao ex) {
        this.explosoes.add(ex);
    }
    
    public void explodir(ControleDeJogo cj,ArrayList<Personagem> umaFase,Set<Posicao> bombasExplodidas) {
        //Posicao pBomba = b.getPosicao(); 
        umaFase.remove(this);
        
        if (bombasExplodidas.contains(pPosicao)) { //hashset para evitar overflow
                return;
        }
        bombasExplodidas.add(pPosicao);
        
        //verifica os espacos vazios ao redor da bomba e ajeita as explosoes nos lugares.
        explosao(0).getPosicao().copia(pPosicao);
        explosao(0).setMorrendo(true); 
       
        if (!cj.HaPersonagemAcima(pPosicao,umaFase)) {
            explosao(1).setPosicao(pPosicao.getLinha()-1, pPosicao.getColuna());
            explosao(1).setMorrendo(true);               
        }
        if (!cj.HaPersonagemAbaixo(pPosicao,umaFase)) {
            explosao(2).setPosicao(pPosicao.getLinha()+1, pPosicao.getColuna());
            explosao(2).setMorrendo(true);   
        }
        if (!cj.HaPersonagemNaEsquerda(pPosicao,umaFase)) {
            explosao(3).setPosicao(pPosicao.getLinha(), pPosicao.getColuna()-1);
            explosao(3).setMorrendo(true); 
        }
        if (!cj.HaPersonagemNaDireita(pPosicao,umaFase)) {
            explosao(4).setPosicao(pPosicao.getLinha(), pPosicao.getColuna()+1);
            explosao(4).setMorrendo(true); 
        }
        if (!cj.HaPersonagemDiagonalSE(pPosicao,umaFase)) {
            explosao(5).setPosicao(pPosicao.getLinha()-1, pPosicao.getColuna()-1);
            explosao(5).setMorrendo(true);    
        }
        if (!cj.HaPersonagemDiagonalSD(pPosicao,umaFase)) {
            explosao(6).setPosicao(pPosicao.getLinha()-1, pPosicao.getColuna()+1);
            explosao(6).setMorrendo(true); 
        }
        if (!cj.HaPersonagemDiagonalIE(pPosicao,umaFase)) {
            explosao(7).setPosicao(pPosicao.getLinha()+1, pPosicao.getColuna()-1);
            explosao(7).setMorrendo(true); 
        }
        if (!cj.HaPersonagemDiagonalID(pPosicao,umaFase)) {
            explosao(8).setPosicao(pPosicao.getLinha()+1, pPosicao.getColuna()+1);
            explosao(8).setMorrendo(true); 
        }
        
        //agora verifica se ha algum tipo de personagem em volta da bomba, e dependendo de qual ele morrera
        for (int i = umaFase.size()-1; i >= 0; i--) { //EM ORDEM DECRESCENTE POIS O HEROI DEVE SER O ULTIMO A MORRER
            Personagem pIesimoPersonagem = umaFase.get(i);
            int linPersonagem = pIesimoPersonagem.getPosicao().getLinha();
            int colPersonagem = pIesimoPersonagem.getPosicao().getColuna();
            
            if (    (linPersonagem == pPosicao.getLinha() && colPersonagem == pPosicao.getColuna()) ||
                    (linPersonagem == pPosicao.getLinha()+1 && colPersonagem == pPosicao.getColuna()) ||
                    (linPersonagem == pPosicao.getLinha()-1 && colPersonagem == pPosicao.getColuna()) ||   
                    (linPersonagem == pPosicao.getLinha() && colPersonagem == pPosicao.getColuna()+1) ||
                    (linPersonagem == pPosicao.getLinha() && colPersonagem == pPosicao.getColuna()-1) ||
                    (linPersonagem == pPosicao.getLinha()+1 && colPersonagem == pPosicao.getColuna()+1) ||
                    (linPersonagem == pPosicao.getLinha()+1 && colPersonagem == pPosicao.getColuna()-1) ||   
                    (linPersonagem == pPosicao.getLinha()-1 && colPersonagem == pPosicao.getColuna()-1) ||
                    (linPersonagem == pPosicao.getLinha()-1 && colPersonagem == pPosicao.getColuna()+1)) {
                
                
                //se houver outra bomba ao redor, detona ela
                if (pIesimoPersonagem instanceof Bomb) {
                    Bomb novaBomba = (Bomb) pIesimoPersonagem;
                    novaBomba.explodir(cj,umaFase,bombasExplodidas); // chamada nova
                }
                //detona os demais personagens ao redor da bomba
                if (pIesimoPersonagem instanceof ParedeAmarela || pIesimoPersonagem instanceof Hero || pIesimoPersonagem.isbTransponivel()) {
                    pIesimoPersonagem.setMorrendo(true);  
                }
            }
        }        
    }




}
