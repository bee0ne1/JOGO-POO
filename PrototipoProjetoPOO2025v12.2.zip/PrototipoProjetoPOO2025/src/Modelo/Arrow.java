/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;


import Controler.ControleDeJogo;
import auxiliar.Posicao;
import java.util.ArrayList;

/**
 *
 * @author bedos
 */
public class Arrow extends Personagem{
    
    public Arrow(String sNomeImagePNG,String direction) {
        super(sNomeImagePNG);
        this.bMortal = true;
        this.direction = direction;
    }
    
    public void computeDirection(ControleDeJogo cj,Posicao pArrow,ArrayList<Personagem> umaFase) {
        switch (this.direction) {
                case "right":
                    importIcon("arrow_right.png");
                    if (!cj.HaPersonagemAbaixo(pArrow, umaFase)) {
                        direction = "down";
                        moveDown();
                    } else if (!cj.HaPersonagemNaDireita(pArrow, umaFase)) {
                        direction = "right";
                        moveRight();
                    } else {
                        direction = "up";
                        moveUp();
                    } break;
                case "down":
                    importIcon("arrow_down.png");
                    if (!cj.HaPersonagemNaEsquerda(pArrow, umaFase)) {
                        direction = "left";
                        moveLeft();
                    } else if (!cj.HaPersonagemAbaixo(pArrow, umaFase)) {
                        direction = "down";
                        moveDown();
                    } else {
                        direction = "right";
                        moveRight();
                    } break;
                case "left":
                    importIcon("arrow_left.png");
                    if (!cj.HaPersonagemAcima(pArrow, umaFase)) {
                        direction = "up";
                        moveUp();
                    } else if (!cj.HaPersonagemNaEsquerda(pArrow, umaFase)) {
                        direction = "left"; 
                        moveLeft();
                    } else {
                        direction = "down";  
                        moveDown();// última opção
                    }
                    break;
                case "up":
                    importIcon("arrow_up.png");
                    if (!cj.HaPersonagemNaDireita(pArrow, umaFase)) {
                        direction = "right"; 
                        moveRight();
                    } else if (!cj.HaPersonagemAcima(pArrow, umaFase)) {
                        direction = "up";
                        moveUp();// segue reto
                    } else {
                        direction = "left"; 
                        moveLeft();// última opção
                    }
                    break;
            }
    }
    
    
    
}
