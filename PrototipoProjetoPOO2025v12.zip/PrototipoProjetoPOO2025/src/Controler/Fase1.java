/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controler;
import Modelo.Personagem;
import Modelo.Hero;

import java.util.ArrayList;

/**
 *
 * @author bruno
 */
public class Fase1 extends Fase {
    
    @Override
    public ArrayList<Personagem> carregarFase(Hero hero) {
        ArrayList<Personagem> fase1 = new ArrayList<>();
        
        
        fase1.add(hero);
        hero.setPosicao(1, 1);
        
        
        adicionarParedes(fase1, "blue_wall_h1.png", new int[][] {
            {0, 0}, {0, 2}, {0, 5}, {0, 7}, {0, 10}, {0, 12}, {0, 14},
            {4, 4},
            {5, 8},
            {7, 1},
            {9, 11},
            {11, 4},{11, 9},
            {13, 10},
            {14, 9},
            {15, 10},
            {18, 10},
            {20, 1},{20, 3},{20, 5},{20, 7},{20, 9},{20, 12},
            {24, 7},{24, 9},
            {26, 0},{26, 2},{26, 7},{26, 9},
            {30, 0},{30, 5},{30, 8},{30, 11},{30, 13},
        });
               
        adicionarParedes(fase1, "blue_wall_h2.png", new int[][] {
            {0, 1},{0, 3},{0, 6},{0, 8},{0, 11},{0, 13},{0, 15},
            {4, 5},
            {5, 9},
            {7, 2},
            {9, 12},
            {11, 5},{11, 10},
            {13, 11},
            {14, 10},
            {15, 11},
            {18, 11},
            {20, 2},{20, 4},{20, 6},{20, 8},{20, 10},{20, 13},
            {24, 8},{24, 10},
            {26, 1},{26, 3},{26, 8},{26, 10},
            {30, 1},{30, 6},{30, 9},{30, 12},{30, 14},
        });
        
        
        adicionarParedes(fase1, "blue_wall_v1.png", new int[][] {
            {2, 4},{2, 9},{2, 15},
            {3, 0}, 
            {4, 13},{4, 15},
            {6, 0},{6, 5},{6, 8},{6, 13},
            {8, 0},
            {9, 5},
            {10, 0},{10, 8},{10, 12},{10, 15},
            {12, 5},{12, 12},{12, 15},
            {13, 0},
            {14, 15},
            {15, 5},
            {16, 0},{16, 15},
            {18, 0},{18, 15},
            {21, 10},{21, 13},
            {22, 15},
            {23, 0},
            {24, 0},{24, 6},
            {25, 15},
            {26, 6},{26, 12},{26, 14},
            {27, 0},{27, 10},
            {27, 15},
            {29, 4},{29, 10},
        });
        
        adicionarParedes(fase1, "blue_wall_v2.png", new int[][] {
            {3, 4},{3, 9},{3, 15},
            {4, 0},
            {5, 13},{5, 15},
            {7, 0},{7, 5},{7, 8},{7, 13},
            {9, 0},
            {10, 5},
            {11, 0},{11, 8},{11, 12},{11, 15},
            {13, 5},{13, 12},{13, 15},
            {14, 0},
            {15, 15},
            {16, 5},
            {17, 0},{17, 15},
            {19, 0},{19, 15},
            {22, 10},{22, 13},
            {23, 15},
            {25, 6},
            {26, 15},
            {27, 6},{27, 12},{27, 14},
            {28, 0},{28, 10},{28, 15},
            {30, 4},{30, 10},
        });
        
        adicionarParedes(fase1, "blue_ball.png", new int[][] {
            {0, 4},{0, 9},
            {1, 11},{1, 15},
            {2, 0},{2, 8},{2, 11},
            {3, 2},{3, 11},
            {4, 11},
            {5, 5},{5, 11},
            {6, 15},
            {7, 3},{7, 15},
            {8, 13},
            {9, 8},{9, 10},{9, 15},
            {12, 0},
            {14, 5},{14, 6},
            {15, 12},
            {16, 11},
            {19, 10},
            {20, 0},{20, 15},
            {21, 0},{21, 4},{21, 15},
            {24, 14},{24, 15},
            {25, 0},
            {27, 4},
            {29, 0},{29, 15},
            {30, 2},{30, 15},
        });
        
        adicionarParedes(fase1, "purple_ball.png", new int[][] {
            {1, 0},{1, 4},{1, 8},
            {5, 0},{5, 7},{5, 10},
            {8, 5},{8, 6},{8, 8},{8, 15},
            {9, 13},
            {11, 3},
            {11, 0},{11, 6},{11, 7},
            {14, 8},
            {15, 0},
            {15, 14},
            {17, 11},
            {22, 12},
            {23, 4},
            {24, 4},{24, 12},
            {26, 4},
            {27, 13},
            {29, 6},
            {30, 3},{30, 7},
        });
        
        adicionarParedesAmarelas(fase1, "yellow_wall_horizontal.png", new int[][] {
            {4, 7},
            {7, 7},    
            {16, 1},{16, 4},{16, 9},{16, 12},{16, 14},
            {17, 3},{17, 7},{17, 8},
            {18, 2},
            {19, 2},{19, 7},
            {20, 11},
            {24, 5},
            {25, 11},
        });
        
        adicionarParedesAmarelas(fase1, "yellow_wall_vertical.png", new int[][] {
            {4, 2},
            {13, 7},
            {17, 1},{17, 4},
            {18, 1},{18, 3},{18, 8},{18, 9},
            {19, 4},{19, 5},
            {23, 8},
        });
        
        adicionarDusts(fase1, new int[][] {
            {6, 11},
            {7, 11},
            {8, 11},
        });
        
        adicionarChaves(fase1, new int[][] {
            {19, 1},
            {21, 12},
        });
        
        adicionarCadeados(fase1, new int[][] {
            {12, 10},
            {21, 14},
        });
        
        adicionarBombas(fase1, new int[][] {
            {8, 1},
            {13, 2},
            {16, 3},
        });
      
        adicionarBaterias(fase1, new int[][] {
            {6, 1},
            {14, 11},
        });
        
        adicionarBolts(fase1, new int[][] {
            {1, 9},
            {7, 6},
            {10, 4},{10, 6},
            {19, 8},
            {22, 6},
            {25, 7},
            {28, 8},
            {29, 14},
        });
        
        adicionarLancaChamas(fase1,"down",50,10,13);
        adicionarLancaChamas(fase1,"right",50,22,0);
        
        adicionarPortal(fase1,2,6,1,2);
        adicionarPortal(fase1,2,13,2,1);
        
        adicionarVida(fase1,24,2);
       
        adicionarSaida(fase1,28,2);
        
        
        return fase1;
    }
}
