/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

import java.io.Serializable;

/**
 *
 * @author bedos
 */
public class Chave extends Personagem implements Serializable {
    
    public Chave(String sNomeImagePNG) {
        super(sNomeImagePNG);
    }
}
