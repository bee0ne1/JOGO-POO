/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controler;
import Modelo.Parede;
import Modelo.Personagem;
import Modelo.Caveira;
import Modelo.Hero;
import Modelo.Parede;
import Modelo.ParedeAmarela;
import Modelo.Bomb;
import Modelo.Explosao;
import Modelo.Chaser;
import Modelo.Battery;
import Modelo.Bolt;
import Modelo.Portal;
import Modelo.Fogo;
import Modelo.LancaChamas;
import Modelo.BichinhoVaiVemHorizontal;
import Auxiliar.Consts;
import Auxiliar.Desenho;
import Modelo.BichinhoVaiVemVertical;
import Modelo.ZigueZague;
import auxiliar.Posicao;
import java.util.ArrayList;

/**
 *
 * @author bruno
 */
public class Fase1 extends Fase {
    
    @Override
    public ArrayList<Personagem> carregarFase(Hero hero) {
        ArrayList<Personagem> fase1 = new ArrayList<>();
        
        
        fase1.add(hero);
        hero.setPosicao(3, 3);
        
        
        adicionarParedes(fase1, "blue_wall_h1.png", new int[][] {
        {0, 0}, {0, 2}, {0, 5}, {0, 7}, {0, 10}, {0, 12}, {0, 14}
        });
               
        adicionarParedes(fase1, "blue_wall_h2.png", new int[][] {
        {0, 1}, {0, 3}, {0, 6}, {0, 8}, {0, 11}, {0, 13}, {0, 15}
        });
        
        adicionarParedes(fase1, "blue_ball.png", new int[][] {
        {0, 4}, {0, 9}
        });
        
        adicionarParedes(fase1, "blue_wall_v1.png", new int[][] {
        {1, 0}
        });
        
        adicionarParedes(fase1, "blue_wall_v2.png", new int[][] {
        {2, 0}
        });
        
        adicionarParedesAmarelas(fase1, "yellow_wall_horizontal.png", new int[][] {
        {2, 4},{9, 8},{8, 5}
        });
        
        adicionarLancaChamas(fase1, new int[][] {
        {5, 5},{5,8}
        });
        
        adicionarBombas(fase1, new int[][] {
        {8, 1},{8,2}
        });
      
        adicionarBaterias(fase1, new int[][] {
        {2, 6}
        });
        
        adicionarBolts(fase1, new int[][] {
        {2, 5}
        });
        
        adicionarPortal(fase1,7,7,1,2);
        adicionarPortal(fase1,7,12,2,1);
        
        
        
        return fase1;
    }
}
