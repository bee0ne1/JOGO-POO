/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controler;

import Modelo.Hero;
import Modelo.Personagem;
import java.util.ArrayList;

/**
 *
 * @author bedos
 */
public class Fase4 extends Fase{
     @Override
    protected ArrayList<Personagem> carregarFase(Hero hero) {
        ArrayList<Personagem> fase4 = new ArrayList<>();
        
        fase4.add(hero);
        hero.setPosicao(2, 4);
        
        // Borda superior (linha 0) — horizontal
        adicionarParedes(fase4, "blue_wall_h1.png", new int[][] {
            {0, 0}, {0, 2}, {0, 4}, {0, 6}, {0, 8}, {0, 10}, {0, 12}, {0, 14}
        });
        adicionarParedes(fase4, "blue_wall_h2.png", new int[][] {
            {0, 1}, {0, 3}, {0, 5}, {0, 7}, {0, 9}, {0, 11}, {0, 13}, {0, 15}
        });

        // Borda inferior (linha 30) — horizontal
        adicionarParedes(fase4, "blue_wall_h1.png", new int[][] {
            {30, 0}, {30, 2}, {30, 4}, {30, 6}, {30, 8}, {30, 10}, {30, 12}, {30, 14}
        });
        adicionarParedes(fase4, "blue_wall_h2.png", new int[][] {
            {30, 1}, {30, 3}, {30, 5}, {30, 7}, {30, 9}, {30, 11}, {30, 13}, {30, 15}
        });

        // Borda esquerda (coluna 0) — vertical
        adicionarParedes(fase4, "blue_wall_v1.png", new int[][] {
            {1, 0}, {3, 0}, {5, 0}, {7, 0}, {9, 0}, {11, 0}, {13, 0}, {15, 0},
            {17, 0}, {19, 0}, {21, 0}, {23, 0}, {25, 0}, {27, 0}, 
        });
        adicionarParedes(fase4, "blue_wall_v2.png", new int[][] {
            {2, 0}, {4, 0}, {6, 0}, {8, 0}, {10, 0}, {12, 0}, {14, 0}, {16, 0},
            {18, 0}, {20, 0}, {22, 0}, {24, 0}, {26, 0}, {28, 0}
        });

        // Borda direita (coluna 15) — vertical
        adicionarParedes(fase4, "blue_wall_v1.png", new int[][] {
            {1, 15}, {3, 15}, {5, 15}, {7, 15}, {9, 15}, {11, 15}, {13, 15}, {15, 15},
            {17, 15}, {19, 15}, {21, 15}, {23, 15}, {25, 15}, {27, 15},
        });
        adicionarParedes(fase4, "blue_wall_v2.png", new int[][] {
            {2, 15}, {4, 15}, {6, 15}, {8, 15}, {10, 15}, {12, 15}, {14, 15}, {16, 15},
            {18, 15}, {20, 15}, {22, 15}, {24, 15}, {26, 15}, {28, 15}
        });
        
        adicionarParedes(fase4, "blue_ball.png", new int[][] {
            {7, 4}, {7, 5}, {7, 6}, {7, 7}, {7, 8}, {7, 9}, {7, 10},
            {8, 4},{8, 10},
            {9, 4},{9, 10},
            {10, 4},{10, 5},{10, 6},{10, 8},{10, 9},{10, 10},
            {11, 6},{11, 8},
            {12, 6},{12, 8},
            {13, 6},{13, 8},
            {14, 6},{14, 8},
            {15, 6},{15, 8},
            {16, 6},{16, 8},
            {17, 6},{17, 8},
            {18, 6},{18, 8},
            {29, 0}, {29, 15}
        });
        
        adicionarParedes(fase4, "purple_ball.png", new int[][] {
            {1,2},{2,2},
            {27,11},{27,13},{27,14},
            {28,11},
            {29,11},
        });
        
        adicionarParedesAmarelas(fase4,"yellow_wall_horizontal.png",new int[][] {
            {1,12},
            {2,12}, 
            {3,13},{3,14},
            {10, 7},
            {25,1},{25,2},{25,3},
            {26,1},{26,2},{26,3},
            {27,1},{27,3},
            {28,3},
            {29,1},{29,3},
        });
       
        adicionarDusts(fase4, new int[][] {
            {11, 7},
            {12, 7},
            {13, 7},
            {14, 7},
            {15, 7},
            {16, 7},
            {17, 7},
            {18, 7},
        });
        
        adicionarChaves(fase4, new int[][] {
            {28, 1},
            {1,14}
        });
        
        adicionarCadeados(fase4, new int[][] {
            {2, 1},
            {27, 12},
        });
        
        adicionarBaterias(fase4, new int[][] {
         {1, 1}
        });
        adicionarBombas(fase4, new int[][] {
            {28, 13}
        });
        
        adicionarBolts(fase4, new int[][] {
            {9, 7},
        });
        
        adicionarChaser(fase4,"red",8,7);
        
        adicionarVida(fase4,8,9);
        
        adicionarSaida(fase4,1,7);
        
        
        return fase4;
    }
}
