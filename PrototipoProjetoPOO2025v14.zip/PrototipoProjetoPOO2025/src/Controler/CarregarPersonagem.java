/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controler;

import java.io.*;
import java.util.zip.*;
import Modelo.Personagem;
/**
 *
 * @author bedos
 */
public class CarregarPersonagem {
    public static Personagem carregarPersonagemDeZip(File zipFile) {
        try {
            ZipInputStream zis = new ZipInputStream(new FileInputStream(zipFile));
            ZipEntry entry = zis.getNextEntry();

            if (entry != null) {
                ObjectInputStream ois = new ObjectInputStream(zis);
                Personagem p = (Personagem) ois.readObject();
                zis.closeEntry();
                zis.close();
                return p;
            }
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        }
        return null;
    }
}
