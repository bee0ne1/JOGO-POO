/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controler;
import Modelo.Parede;
import Modelo.Personagem;
import Modelo.Caveira;
import Modelo.Hero;
import Modelo.Parede;
import Modelo.ParedeAmarela;
import Modelo.Bomb;
import Modelo.Explosao;
import Modelo.Chaser;
import Modelo.Battery;
import Modelo.Bolt;
import Modelo.Portal;
import Modelo.Fogo;
import Modelo.LancaChamas;
import Modelo.BichinhoVaiVemHorizontal;
import Auxiliar.Consts;
import Auxiliar.Desenho;
import Modelo.BichinhoVaiVemVertical;
import Modelo.ZigueZague;
import auxiliar.Posicao;
import java.util.ArrayList;

/**
 *
 * @author bruno
 */
public class Fase1 implements Fase {
    
    /*glossario
    bhl = blue wall horizontal left
    bhr = blue wall horizontal right
    bvu = blue wall vertical up
    bvd = blue wall vertical down
    yh = yellow wall horizontal
    yv = yellow wall vertical
    bb = blue ball
    pb = purble ball
    ba = battery
    bo = bolt
    ex = explosao
    p = portal
    */
    
    @Override
    public ArrayList<Personagem> carregarFase(Hero hero) {
        ArrayList<Personagem> fase1 = new ArrayList<>();
        
        
        fase1.add(hero);
        hero.setPosicao(3, 3);
        
      
        Parede bhl1 = new Parede("blue_wall_h1.png");
        Parede bhl2 = new Parede("blue_wall_h1.png");
        Parede bhl3 = new Parede("blue_wall_h1.png");
        Parede bhl4 = new Parede("blue_wall_h1.png");
        Parede bhl5 = new Parede("blue_wall_h1.png");
        Parede bhl6 = new Parede("blue_wall_h1.png");
        Parede bhl7 = new Parede("blue_wall_h1.png");
        fase1.add(bhl1);
        fase1.add(bhl2);
        fase1.add(bhl3);
        fase1.add(bhl4);
        fase1.add(bhl5);
        fase1.add(bhl6);
        fase1.add(bhl7);
        bhl1.setPosicao(0,0);
        bhl2.setPosicao(0,2);
        bhl3.setPosicao(0,5);
        bhl4.setPosicao(0,7);
        bhl5.setPosicao(0,10);
        bhl6.setPosicao(0,12);
        bhl7.setPosicao(0,14);
        
        
        
        Parede bhr1 = new Parede("blue_wall_h2.png");
        Parede bhr2 = new Parede("blue_wall_h2.png");
        Parede bhr3 = new Parede("blue_wall_h2.png");
        Parede bhr4 = new Parede("blue_wall_h2.png");
        Parede bhr5 = new Parede("blue_wall_h2.png");
        Parede bhr6 = new Parede("blue_wall_h2.png");
        Parede bhr7 = new Parede("blue_wall_h2.png");
        fase1.add(bhr1);
        fase1.add(bhr2);
        fase1.add(bhr3);
        fase1.add(bhr4);
        fase1.add(bhr5);
        fase1.add(bhr6);
        fase1.add(bhr7);
        bhr1.setPosicao(0,1);
        bhr2.setPosicao(0,3);
        bhr3.setPosicao(0,6);
        bhr4.setPosicao(0,8);
        bhr5.setPosicao(0,11);
        bhr6.setPosicao(0,13);
        bhr7.setPosicao(0,15);
        
        
        Parede bvu1 = new Parede("blue_wall_v1.png");
        Parede bvd1 = new Parede("blue_wall_v2.png");
        
        
        
        Parede bb1 = new Parede("blue_ball.png");
        Parede bb2 = new Parede("blue_ball.png");
        fase1.add(bb1);
        fase1.add(bb2);
        bb1.setPosicao(0, 4);
        bb2.setPosicao(0, 9);
        
        
        LancaChamas ft1 = new LancaChamas("flamethrower.png");
        fase1.add(ft1);
        ft1.setPosicao(5, 5);
        Fogo fire1 = new Fogo("transparente.png");
        Fogo fire2 = new Fogo("transparente.png");
        Fogo fire3 = new Fogo("transparente.png");
        fase1.add(fire1);
        fase1.add(fire2);
        fase1.add(fire3);
        ft1.addFogo(fire1);
        ft1.addFogo(fire2);
        ft1.addFogo(fire3);
        
        fire1.setPosicao(0, 0);
        fire2.setPosicao(0, 0);
        fire3.setPosicao(0, 0);
        
        
        LancaChamas ft2 = new LancaChamas("flamethrower.png");
        fase1.add(ft2);
        ft2.setPosicao(5, 8);
        Fogo fire4 = new Fogo("transparente.png");
        Fogo fire5 = new Fogo("transparente.png");
        Fogo fire6 = new Fogo("transparente.png");
        fase1.add(fire4);
        fase1.add(fire5);
        fase1.add(fire6);
        ft2.addFogo(fire4);
        ft2.addFogo(fire5);
        ft2.addFogo(fire6);
        
        fire4.setPosicao(0, 0);
        fire5.setPosicao(0, 0);
        fire6.setPosicao(0, 0);
        
        
      
        ParedeAmarela yh1 = new ParedeAmarela("yellow_wall_horizontal.png");
        ParedeAmarela yh2 = new ParedeAmarela("yellow_wall_horizontal.png");
        ParedeAmarela yh3 = new ParedeAmarela("yellow_wall_horizontal.png");
        fase1.add(yh1);
        fase1.add(yh2);
        fase1.add(yh3);
        yh1.setPosicao(2, 4);
        yh2.setPosicao(9, 8);
        yh3.setPosicao(8, 5);
        bvu1.setPosicao(1,0);
        bvd1.setPosicao(2,0);
        fase1.add(bvu1);
        fase1.add(bvd1);
        
        Battery ba1 = new Battery("battery.png");
        ba1.setPosicao(2, 6);
        fase1.add(ba1);
        
        Bolt bo1 = new Bolt("bolt.png");
        bo1.setPosicao(2, 5);
        fase1.add(bo1);
        
        //PARA CADA BOMBA ADICIONE 9 EXPLOSOES
        Bomb bomb1 = new Bomb("bomb.png");
        Bomb bomb2 = new Bomb("bomb.png");
        bomb1.setPosicao(8,1);
        bomb2.setPosicao(8,2);
        fase1.add(bomb1);
        fase1.add(bomb2);
        
        Explosao ex1 = new Explosao("transparente.png");
        Explosao ex2 = new Explosao("transparente.png");
        Explosao ex3 = new Explosao("transparente.png");
        Explosao ex4 = new Explosao("transparente.png");
        Explosao ex5 = new Explosao("transparente.png");
        Explosao ex6 = new Explosao("transparente.png");
        Explosao ex7 = new Explosao("transparente.png");
        Explosao ex8 = new Explosao("transparente.png");
        Explosao ex9 = new Explosao("transparente.png");
        bomb1.addExplosao(ex1);
        bomb1.addExplosao(ex2);
        bomb1.addExplosao(ex3);
        bomb1.addExplosao(ex4);
        bomb1.addExplosao(ex5);
        bomb1.addExplosao(ex6);
        bomb1.addExplosao(ex7);
        bomb1.addExplosao(ex8);
        bomb1.addExplosao(ex9);
        
        
        Explosao ex10 = new Explosao("transparente.png");
        Explosao ex11 = new Explosao("transparente.png");
        Explosao ex12 = new Explosao("transparente.png");
        Explosao ex13 = new Explosao("transparente.png");
        Explosao ex14 = new Explosao("transparente.png");
        Explosao ex15 = new Explosao("transparente.png");
        Explosao ex16 = new Explosao("transparente.png");
        Explosao ex17 = new Explosao("transparente.png");
        Explosao ex18 = new Explosao("transparente.png");
        bomb2.addExplosao(ex10);
        bomb2.addExplosao(ex11);
        bomb2.addExplosao(ex12);
        bomb2.addExplosao(ex13);
        bomb2.addExplosao(ex14);
        bomb2.addExplosao(ex15);
        bomb2.addExplosao(ex16);
        bomb2.addExplosao(ex17);
        bomb2.addExplosao(ex18);
        
        
        fase1.add(ex1);
        fase1.add(ex2);
        fase1.add(ex3);
        fase1.add(ex4);
        fase1.add(ex5);
        fase1.add(ex6);
        fase1.add(ex7);
        fase1.add(ex8);
        fase1.add(ex9);
        fase1.add(ex10);
        fase1.add(ex11);
        fase1.add(ex12);
        fase1.add(ex13);
        fase1.add(ex14);
        fase1.add(ex15);
        fase1.add(ex16);
        fase1.add(ex17);
        fase1.add(ex18);
        ex1.setPosicao(0, 0);
        ex2.setPosicao(0, 0);
        ex3.setPosicao(0, 0);
        ex4.setPosicao(0, 0);
        ex5.setPosicao(0, 0);
        ex6.setPosicao(0, 0);
        ex7.setPosicao(0, 0);
        ex8.setPosicao(0, 0);
        ex9.setPosicao(0, 0);
        ex10.setPosicao(0, 0);
        ex11.setPosicao(0, 0);
        ex12.setPosicao(0, 0);
        ex13.setPosicao(0, 0);
        ex14.setPosicao(0, 0);
        ex15.setPosicao(0, 0);
        ex16.setPosicao(0, 0);
        ex17.setPosicao(0, 0);
        ex18.setPosicao(0, 0);
        
        Portal p1 = new Portal("portal.png",1,2);
        Portal p2 = new Portal("portal.png",2,1);
        fase1.add(p1);
        fase1.add(p2);
        p1.setPosicao(7, 7);
        p2.setPosicao(7, 12);
        
        
        
        
        return fase1;
    }

    
    
    
}
