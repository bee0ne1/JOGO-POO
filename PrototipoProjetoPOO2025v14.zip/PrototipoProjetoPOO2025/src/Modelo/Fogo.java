package Modelo;

import Auxiliar.Desenho;
import Controler.Tela;
import java.awt.Graphics;
import java.io.Serializable;

public class Fogo extends Personagem implements Serializable { //implements Serializable{
    private int tempoSpawn = 0;
    private boolean ativo = false;
    
    public Fogo(String sNomeImagePNG) {
        super(sNomeImagePNG);
        this.bMortal = true;
        this.bTransponivel = false;
    }
    
    
    /*
    @Override
    public void autoDesenho() {
        super.autoDesenho();
        if(!this.moveRight())
            Desenho.acessoATelaDoJogo().removePersonagem(this);
    }
    */

    public int getTempoSpawn() {
        return tempoSpawn;
    }

    public void setTempoSpawn(int tempoSpawn) {
        this.tempoSpawn = tempoSpawn;
    }

    public boolean isAtivo() {
        return ativo;
    }

    public void setAtivo(boolean ativo) {
        this.ativo = ativo;
    }
    
    
    

}
