/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controler;

import Modelo.Hero;
import Modelo.Personagem;
import Modelo.ZigueZague;
import java.util.ArrayList;

/**
 *
 * @author bedos
 */
public class FaseTeste extends Fase {
    @Override
    public ArrayList<Personagem> carregarFase(Hero hero) {
        ArrayList<Personagem> faseTeste = new ArrayList<>();
        
        faseTeste.add(hero);
        hero.setPosicao(1, 1);
        
        adicionarParedes(faseTeste, "blue_wall_h1.png", new int[][] {
        {0, 0}, {0, 2}, {0, 5}, {0, 7}, {0, 10}, {0, 12}, {0, 14},
        });
        
        adicionarParedes(faseTeste, "blue_wall_h2.png", new int[][] {
        {0, 1},{0, 3},{0, 6},{0, 8},{0, 11},{0, 13},{0, 15},
        
        });
        
        adicionarParedes(faseTeste, "blue_ball.png", new int[][] {
        {0, 4},{0, 9},                
        });
        
        adicionarParedes(faseTeste, "blue_wall_v1.png", new int[][] {
        {1, 0},
        });
        
        adicionarParedes(faseTeste, "blue_wall_v2.png", new int[][] {
        {2, 0},
        });
        
        
        adicionarBombas(faseTeste, new int[][] {
        {8, 1}
        });
      
        adicionarBaterias(faseTeste, new int[][] {
        {6, 1}
        });
        
        adicionarBolts(faseTeste, new int[][] {
        {1, 9}
        });
        
        adicionarDusts(faseTeste, new int[][] {
        {3, 7}
        });
        
        adicionarParedesAmarelas(faseTeste, "yellow_wall_horizontal.png", new int[][] {
        {9, 8},
        });
        
        adicionarChaves(faseTeste, new int[][] {
        {4, 7}
        });
        
        adicionarCadeados(faseTeste, new int[][] {
        {4, 9}
        });
        
        adicionarLancaChamas(faseTeste,"down",50,5,5);
        adicionarLancaChamas(faseTeste,"right",100,5,6);
        
        
        //adicionarChaser(faseTeste,"red",8,8);
        adicionarVida(faseTeste,9,9);
        
        ZigueZague z = new ZigueZague("caveira.png");
        faseTeste.add(z);
        z.setPosicao(8, 8);
        
        
        return faseTeste;
    }
}
