/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controler;

import Modelo.Hero;
import Modelo.Personagem;
import java.util.ArrayList;

/**
 *
 * @author bedos
 */
public class Fase5 extends Fase {

    @Override
    protected ArrayList<Personagem> carregarFase(Hero hero) {
        ArrayList<Personagem> fase5 = new ArrayList<>();
        
        fase5.add(hero);
        hero.setPosicao(2, 4);
        
      
        adicionarParedes(fase5, "blue_ball.png", new int[][] {
            {0, 0}, {0, 2}, {0, 4}, {0, 6}, {0, 8}, {0, 10}, {0, 12}, {0, 14},{0, 1}, {0, 3}, {0, 5}, {0, 7}, {0, 9}, {0, 11}, {0, 13}, {0, 15},
            {30, 1}, {30, 3}, {30, 5}, {30, 7}, {30, 9}, {30, 11}, {30, 13}, {30, 15},{30, 1}, {30, 3}, {30, 5}, {30, 7}, {30, 9}, {30, 11}, {30, 13}, {30, 15},
            {1, 0}, {3, 0}, {5, 0}, {7, 0}, {9, 0}, {11, 0}, {13, 0}, {15, 0},
            {17, 0}, {19, 0}, {21, 0}, {23, 0}, {25, 0}, {27, 0},{2, 0}, {4, 0}, {6, 0}, {8, 0}, {10, 0}, {12, 0}, {14, 0}, {16, 0},
            {18, 0}, {20, 0}, {22, 0}, {24, 0}, {26, 0}, {28, 0}, {1, 15}, {3, 15}, {5, 15}, {7, 15}, {9, 15}, {11, 15}, {13, 15}, {15, 15},
            {17, 15}, {19, 15}, {21, 15}, {23, 15}, {25, 15}, {27, 15}, {2, 15}, {4, 15}, {6, 15}, {8, 15}, {10, 15}, {12, 15}, {14, 15}, {16, 15},
            {18, 15}, {20, 15}, {22, 15}, {24, 15}, {26, 15}, {28, 15},{29,15}, {29,0},{30,0},{30,2},{30,4},{30,6},{30,8},{30,10},{30,12},{30,14},
        });
        
        adicionarArrow(fase5,"right",29,7);
        adicionarArrow(fase5,"left",1,7);
        
        adicionarInimigoHorizontal(fase5,7,2);
        adicionarInimigoHorizontal(fase5,14,2);
        adicionarInimigoHorizontal(fase5,21,2);
        adicionarInimigoHorizontal(fase5,28,2);
        
        adicionarChaser(fase5,"metroid",30,2);
        adicionarChaser(fase5,"metroid",30,13);
        adicionarChaser(fase5,"metroid",27,2);
        adicionarChaser(fase5,"metroid",27,13);
        adicionarChaser(fase5,"metroid",22,2);
        adicionarChaser(fase5,"metroid",22,13);
        adicionarChaser(fase5,"metroid",17,2);
        adicionarChaser(fase5,"metroid",17,13);
        adicionarChaser(fase5,"metroid",12,3);
        adicionarChaser(fase5,"metroid",12,11);
        adicionarChaser(fase5,"metroid",7,2);
        adicionarChaser(fase5,"metroid",7,13);
        adicionarChaser(fase5,"metroid",2,2);
        adicionarChaser(fase5,"metroid",2,13);
        
        
    adicionarLancaChamas(fase5, "down", 3, 16, 3);
    adicionarLancaChamas(fase5, "up", 3, 15, 3);
    adicionarLancaChamas(fase5, "down", 3, 16,7);
    adicionarLancaChamas(fase5, "up", 3, 15, 7);
    adicionarLancaChamas(fase5, "down", 3, 16,12);
    adicionarLancaChamas(fase5, "up", 3, 15, 12);
    
    adicionarBaterias(fase5, new int[][] {
         {3, 6},{3, 8},
        });
        
    
    
        return fase5;
    }
    
}
