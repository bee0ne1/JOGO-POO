/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

import Controler.ControleDeJogo;
import Controler.Tela;
import auxiliar.Posicao;
import java.util.ArrayList;

/**
 *
 * @author bedos
 */
public class Portal extends Personagem {
    private int nPortal;
    private int nConexao;
    private int tempoTeleporte = 10;
    
    public Portal(String sNomeImagePNG, int nPortal, int nConexao) {
        super(sNomeImagePNG);
        this.nPortal = nPortal;
        this.nConexao = nConexao;
        this.bMortal = false;
        this.bTransponivel = false;
    }

    public int getnPortal() {
        return nPortal;
    }

    public void setnPortal(int nPortal) {
        this.nPortal = nPortal;
    }

    public int getnConexao() {
        return nConexao;
    }

    public void setnConexao(int nConexao) {
        this.nConexao = nConexao;
    }
    
    
    public void teleportarHeroi(ControleDeJogo cj,Hero hero,ArrayList<Personagem> umaFase,Tela tela) {
        Posicao pHero = hero.getPosicao();
        
        if (hero.isTeleporteInicio()) {

            if (tempoTeleporte == 10) 
                hero.importIcon("explosion1.png");
            if (tempoTeleporte == 6) 
                hero.importIcon("explosion2.png");  
            if (tempoTeleporte == 3) 
                hero.importIcon("explosion3.png");

            tempoTeleporte--;

            if (tempoTeleporte <= 0) {
                //encontra qual portal esta conectado com o que o robo interagiu, e teleporta o robo para este portal
                for (int i=1; i<umaFase.size();i++){
                    if (umaFase.get(i) instanceof Portal) {
                        Portal portalB = (Portal) umaFase.get(i);

                        if(nConexao == portalB.getnPortal()) {
                            Posicao pPortalB = portalB.getPosicao();
                            if ("down".equals(hero.getDirection())) 
                                pHero.copia(cj.proximaPosicao(pPortalB,"down"));
                            else if ("up".equals(hero.getDirection())) 
                                pHero.copia(cj.proximaPosicao(pPortalB,"up"));
                            else if ("right".equals(hero.getDirection())) 
                                pHero.copia(cj.proximaPosicao(pPortalB,"right"));
                            else if ("left".equals(hero.getDirection())) 
                                pHero.copia(cj.proximaPosicao(pPortalB,"left"));
                        }
                    }    
                }
            
            
            tela.atualizaCamera();
            tempoTeleporte = 10;
            hero.setTeleporteInicio(false);
            hero.setTeleporteFim(true);

            }   
              
        }
        if (hero.isTeleporteFim()) {
            if (tempoTeleporte == 10) 
                hero.importIcon("explosion1.png");
            if (tempoTeleporte == 6) 
                hero.importIcon("explosion2.png");
            if (tempoTeleporte == 3) 
                hero.importIcon("explosion3.png");

            tempoTeleporte--;
            
            if (tempoTeleporte <= 0) {
                hero.importIcon("robbo_front.png");
                hero.setTeleporteFim(false);
                tempoTeleporte = 10;
            }
            
        }     
    }
    
    
    
    
    
    
    
}
