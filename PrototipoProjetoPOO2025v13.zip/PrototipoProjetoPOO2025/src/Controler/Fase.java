/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controler;

import Modelo.Arrow;
import Modelo.Battery;
import Modelo.BichinhoVaiVemHorizontal;
import Modelo.Bolt;
import Modelo.Bomb;
import Modelo.Cadeado;
import Modelo.Chaser;
import Modelo.Chave;
import Modelo.Dust;
import Modelo.Explosao;
import Modelo.Fogo;
import Modelo.Hero;
import Modelo.LancaChamas;
import Modelo.Life;
import Modelo.Parede;
import Modelo.ParedeAmarela;
import Modelo.Personagem;
import Modelo.Portal;
import Modelo.SaidaFase;
import java.util.ArrayList;

/**
 *
 * @author bedos
 */
public abstract class Fase {
    
    protected abstract ArrayList<Personagem> carregarFase(Hero hero);
    
    protected void adicionarParedes(ArrayList<Personagem> fase, String imagem, int[][] posicoes) {
        for (int[] pos : posicoes) {
            Parede parede = new Parede(imagem);
            parede.setPosicao(pos[0], pos[1]);
            fase.add(parede);
        }
    }
    
    protected void adicionarParedesAmarelas(ArrayList<Personagem> fase, String imagem, int[][] posicoes) {
        for (int[] pos : posicoes) {
            ParedeAmarela paredeA = new ParedeAmarela(imagem);
            paredeA.setPosicao(pos[0], pos[1]);
            fase.add(paredeA);
        }
    }
    
    protected void adicionarBaterias(ArrayList<Personagem> fase, int[][] posicoes) {
        for (int[] pos : posicoes) {
            Battery bateria = new Battery("battery.png");
            bateria.setPosicao(pos[0], pos[1]);
            fase.add(bateria);
        }
    }
    
    protected void adicionarBolts(ArrayList<Personagem> fase, int[][] posicoes) {
        for (int[] pos : posicoes) {
            Bolt bolt = new Bolt("bolt.png");
            bolt.setPosicao(pos[0], pos[1]);
            fase.add(bolt);
        }
    }
    protected void adicionarDusts(ArrayList<Personagem> fase, int[][] posicoes) {
        for (int[] pos : posicoes) {
            Dust dust = new Dust("dust.png");
            dust.setPosicao(pos[0], pos[1]);
            fase.add(dust);
        }
    }
    
    
    protected void adicionarChaves(ArrayList<Personagem> fase, int[][] posicoes) {
        for (int[] pos : posicoes) {
            Chave chave = new Chave("key.png");
            chave.setPosicao(pos[0], pos[1]);
            fase.add(chave);
        }
    }
    
    protected void adicionarCadeados(ArrayList<Personagem> fase, int[][] posicoes) {
        for (int[] pos : posicoes) {
            Cadeado lock = new Cadeado("lock.png");
            lock.setPosicao(pos[0], pos[1]);
            fase.add(lock);
        }
    }
    
    protected void adicionarVida(ArrayList<Personagem> fase,int linha, int coluna) {
        Life vida = new Life("life.png");
        vida.setPosicao(linha, coluna);
        fase.add(vida);
    }
    
    protected void adicionarLancaChamas(ArrayList<Personagem> fase,String direcao, int tempo,int linha, int coluna) {
        LancaChamas lc = null;
        if ("up".equals(direcao)) 
            lc = new LancaChamas("flamethrower_up.png",direcao,tempo);
        else if ("down".equals(direcao)) 
            lc = new LancaChamas("flamethrower_down.png",direcao,tempo);
        else if ("left".equals(direcao)) 
            lc = new LancaChamas("flamethrower_left.png",direcao,tempo);
        else if ("right".equals(direcao)) 
            lc = new LancaChamas("flamethrower_right.png",direcao,tempo);
        
        lc.setPosicao(linha, coluna);
        fase.add(lc);
        for (int i = 0; i < 9; i++) {
            Fogo fogo = new Fogo("transparente.png");
            fogo.setPosicao(0, 0);
            lc.addFogo(fogo);
            fase.add(fogo);
        }
    }
    
    //PARA CADA BOMBA ADICIONE 9 EXPLOSOES
    protected void adicionarBombas(ArrayList<Personagem> fase, int[][] posicoes) {
        for (int[] pos : posicoes) {
            Bomb bomba = new Bomb("bomb.png");
            bomba.setPosicao(pos[0], pos[1]);
            fase.add(bomba);
            for (int i = 0; i < 9; i++) {
                Explosao e = new Explosao("transparente.png");
                e.setPosicao(0, 0);
                bomba.addExplosao(e);
                fase.add(e);
            }
        }
    }
    
    protected void adicionarPortal(ArrayList<Personagem> fase, int linha, int coluna,int nPortal, int nConexao) {
        Portal portal = new Portal("portal.png",nPortal,nConexao);
        portal.setPosicao(linha, coluna);
        fase.add(portal);
    }
    
    protected void adicionarChaser(ArrayList<Personagem> fase,String cor, int linha, int coluna) {
        Chaser chaser = null;
        if ("pink".equals(cor)) 
            chaser = new Chaser("pink.png");
        else if ("red".equals(cor)) 
            chaser = new Chaser("red.png");
        else if ("blue".equals(cor))
            chaser = new Chaser("blue.png");
        else if ("yellow".equals(cor))
            chaser = new Chaser("yellow.png");
        
        chaser.setPosicao(linha,coluna);
        fase.add(chaser);
    }
    
    protected void adicionarArrow(ArrayList<Personagem> fase, String direction,int linha, int coluna) {
        Arrow arrow = null;
        if ("up".equals(direction))
            arrow = new Arrow("arrow_up.png",direction);
        else if ("down".equals(direction))
            arrow = new Arrow("arrow_down.png",direction);
        else if ("left".equals(direction))
            arrow = new Arrow("arrow_left.png",direction);
        else if ("right".equals(direction))
            arrow = new Arrow("arrow_right.png",direction);
        
        arrow.setPosicao(linha, coluna);
        fase.add(arrow);
    }
    
    protected void adicionarCaveiraHorizontal(ArrayList<Personagem> fase, int linha, int coluna) {
        BichinhoVaiVemHorizontal caveira = new BichinhoVaiVemHorizontal("caveira.png");
        caveira.setPosicao(linha, coluna);
        fase.add(caveira);
    }
    
    protected void adicionarSaida(ArrayList<Personagem> fase, int linha, int coluna) {
        SaidaFase saida = new SaidaFase("saida.png");
        saida.setPosicao(linha, coluna);
        fase.add(saida);
    }
    
    
}
