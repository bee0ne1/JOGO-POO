/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;
import java.util.ArrayList;
/**
 *
 * @author bedos
 */
public class Bomb extends Personagem {
   ArrayList<Explosao> explosoes = new ArrayList<>();
    
    public Bomb(String sNomeImagePNG) {
        super(sNomeImagePNG);
    }

    public Explosao explosao(int index) {
        return explosoes.get(index);
    }

    public void addExplosao(Explosao ex) {
        this.explosoes.add(ex);
    }





}
