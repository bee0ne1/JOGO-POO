package Controler;

import Modelo.Personagem;
import Modelo.Caveira;
import Modelo.Hero;
import Modelo.Chaser;
import Modelo.BichinhoVaiVemHorizontal;
import Modelo.Parede;
import Modelo.Battery;
import Modelo.Bolt;
import Modelo.Bullet;
import Auxiliar.Consts;
import Auxiliar.Desenho;
import Modelo.Arrow;
import Modelo.BichinhoVaiVemVertical;
import Modelo.ZigueZague;
import auxiliar.Posicao;
import java.awt.FlowLayout;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Timer;
import java.util.TimerTask;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.zip.GZIPInputStream;
import java.util.zip.GZIPOutputStream;
import javax.swing.JButton;

public class Tela extends javax.swing.JFrame implements MouseListener, KeyListener {

    private Hero hero;
    private ArrayList<Personagem> faseAtual = new ArrayList<>();
    private Fase faseTeste = new FaseTeste();
    private Fase fase1 = new Fase1();
    private Fase fase2 = new Fase2();
    private Fase fase3 = new Fase3();
    //private Fase fase4 = new Fase4();
    //private Fase fase5 = new Fase5;
    private ControleDeJogo cj; 
    private Graphics g2;
    private int cameraLinha = 0;
    private int cameraColuna = 0;

    public Tela() {
        this.cj = new ControleDeJogo(this);
        
        Desenho.setCenario(this);
        initComponents();
        this.addMouseListener(this);
        /*mouse*/

        this.addKeyListener(this);
        /*teclado*/
 /*Cria a janela do tamanho do tabuleiro + insets (bordas) da janela*/
        this.setSize(Consts.RES * Consts.CELL_SIDE + getInsets().left + getInsets().right,
                Consts.RES * Consts.CELL_SIDE + getInsets().top + getInsets().bottom);
        
        
        this.hero = new Hero("robbo_front.png");
        //para testar qualquer fase ao iniciar o jogo, so coloca-la aqui
        this.faseAtual = fase3.carregarFase(this.hero);
        
        /*Cria faseAtual adiciona personagens*/
        //hero = new Hero("robbo_front.png",3,0,9);
        //this.faseAtual.add(hero);
        //this.faseAtual.add(bullet);
        //hero.setPosicao(3, 3);
        //this.atualizaCamera();
        this.atualizaCamera();
        
        /*
        
        /*ZigueZague zz = new ZigueZague("bomb.png");
        zz.setPosicao(5, 5);
        this.addPersonagem(zz);

        BichinhoVaiVemHorizontal bBichinhoH = new BichinhoVaiVemHorizontal("roboPink.png");
        bBichinhoH.setPosicao(3, 3);
        this.addPersonagem(bBichinhoH);

        BichinhoVaiVemHorizontal bBichinhoH2 = new BichinhoVaiVemHorizontal("roboPink.png");
        bBichinhoH2.setPosicao(6, 6);
        this.addPersonagem(bBichinhoH2);
        
        BichinhoVaiVemVertical bVv = new BichinhoVaiVemVertical("Caveira.png");
        bVv.setPosicao(10, 10);
        this.addPersonagem(bVv);        
        
        Caveira bV = new Caveira("caveira.png");
        bV.setPosicao(9, 1);
        this.addPersonagem(bV);
        
        Chaser chase = new Chaser("chaser.png");
        chase.setPosicao(12, 12);
        this.addPersonagem(chase);        
        */
    }
    
    public int getCameraLinha() {
        return cameraLinha;
    }

    public int getCameraColuna() {
        return cameraColuna;
    }

    public boolean ehPosicaoValida(Hero hero,Posicao pHero) {
        return cj.ehPosicaoValida(this.faseAtual,hero,pHero);
    }
     
    public boolean ColisaoBala(Bullet bala,Posicao pBala) {
        return cj.ColisaoBala(this.faseAtual, bala, pBala);
    }
    
    public void addPersonagem(Personagem umPersonagem) {
        faseAtual.add(umPersonagem);
    }

    public void removePersonagem(Personagem umPersonagem) {
        faseAtual.remove(umPersonagem);
    }
    

    public Graphics getGraphicsBuffer() {
        return g2;
    }

    public void paint(Graphics gOld) {
        Graphics g = this.getBufferStrategy().getDrawGraphics();
        /*Criamos um contexto gráfico*/
        g2 = g.create(getInsets().left, getInsets().top, getWidth() - getInsets().right, getHeight() - getInsets().top);
        /**
         * ***********Desenha cenário de fundo*************
         */
        for (int i = 0; i < Consts.RES; i++) {
            for (int j = 0; j < Consts.RES; j++) {
                int mapaLinha = cameraLinha + i;
                int mapaColuna = cameraColuna + j;

                if (mapaLinha < Consts.MUNDO_ALTURA && mapaColuna < Consts.MUNDO_LARGURA) {
                    try {
                        Image newImage = Toolkit.getDefaultToolkit().getImage(
                                new java.io.File(".").getCanonicalPath() + Consts.PATH + "blackTile.png");
                        g2.drawImage(newImage,
                                j * Consts.CELL_SIDE, i * Consts.CELL_SIDE,
                                Consts.CELL_SIDE, Consts.CELL_SIDE, null);
                    } catch (IOException ex) {
                        Logger.getLogger(Tela.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }
            }
        }
        if (!this.faseAtual.isEmpty()) {
            this.cj.desenhaTudo(faseAtual);
            this.cj.processaTudo(faseAtual);
        }

        g.dispose();
        g2.dispose();
        if (!getBufferStrategy().contentsLost()) {
            getBufferStrategy().show();
        }
    }

    public void atualizaCamera() {
        int linha = hero.getPosicao().getLinha();
        int coluna = hero.getPosicao().getColuna();

        cameraLinha = Math.max(0, Math.min(linha - Consts.RES / 2, Consts.MUNDO_ALTURA - Consts.RES));
        cameraColuna = Math.max(0, Math.min(coluna - Consts.RES / 2, Consts.MUNDO_LARGURA - Consts.RES));
    }

    public void go() {
        TimerTask task = new TimerTask() {
            public void run() {
                repaint();
            }
        };
        Timer timer = new Timer();
        timer.schedule(task, 0, Consts.PERIOD);
    }

    public void keyPressed(KeyEvent e) { //ALTERACOES: MUDA A POSICAO DO ROBO CONFORME O INPUT
        if (!hero.isMorrendo() && !hero.isTeleporteInicio() && !hero.isTeleporteFim()) {
            
            if (e.getKeyCode() == KeyEvent.VK_C) { //botao de resetar fase (GASTA UMA VIDA)
                cj.reseta(this.hero, this.faseAtual);
                
            } else if (e.getKeyCode() == KeyEvent.VK_UP) {
                hero.importIcon("robbo_back.png");
                hero.setDirection("up");
                hero.moveUp();


            } else if (e.getKeyCode() == KeyEvent.VK_DOWN) {
                hero.importIcon("robbo_front.png");
                hero.setDirection("down");
                hero.moveDown();


            } else if (e.getKeyCode() == KeyEvent.VK_LEFT) {
                hero.importIcon("robbo_left.png");
                hero.setDirection("left");
                hero.moveLeft();


            } else if (e.getKeyCode() == KeyEvent.VK_RIGHT) {
                hero.importIcon("robbo_right.png");
                hero.setDirection("right");
                hero.moveRight();    


            } else if (e.getKeyCode() == KeyEvent.VK_SPACE) { //comando espaco para atirar
                boolean tiroDisponivel = true;
                //VERIFICACAO QUE O TIRO ANTERIOR DEVE SER APAGADO ANTES DO PROXIMO TIRO, OU SEJA ELE NAO PODE ESTAR NO ARRAYLIST DA FASE
                for (int i = faseAtual.size()-1; i>=1; i--) {
                    if (hero.getBalaHeroi() == faseAtual.get(i)) {
                        tiroDisponivel = false;
                        break;
                    }
                } 
                
                if (hero.getnBaterias()> 0 && cj.PosicaoInicialBala(this.faseAtual,this.hero) && tiroDisponivel) {
                    this.faseAtual.add(hero.getBalaHeroi());

                    if ("down".equals(hero.getDirection())) {
                        hero.getBalaHeroi().setPosicao(hero.getPosicao().getLinha()+1,hero.getPosicao().getColuna());
                    } 
                    else if ("up".equals(hero.getDirection())) {
                        hero.getBalaHeroi().setPosicao(hero.getPosicao().getLinha()-1,hero.getPosicao().getColuna());
                    }
                    else if ("left".equals(hero.getDirection())) {
                        hero.getBalaHeroi().setPosicao(hero.getPosicao().getLinha(),hero.getPosicao().getColuna()-1);
                    }
                    else if ("right".equals(hero.getDirection())) {
                        hero.getBalaHeroi().setPosicao(hero.getPosicao().getLinha(),hero.getPosicao().getColuna()+1);
                    }

                }

                if (hero.getnBaterias()>0 && tiroDisponivel)
                    hero.setnBaterias(hero.getnBaterias()-1); //diminui o numero de balas conforme o usuario aperta a tecla
                System.out.println("numero de tiros: "+hero.getnBaterias());

                }
            }
        
        this.atualizaCamera();
        this.setTitle("-> Cell: " + (hero.getPosicao().getLinha())+ ", " +(hero.getPosicao().getColuna()));

        //repaint(); /*invoca o paint imediatamente, sem aguardar o refresh*/
    }
    
    public void mousePressed(MouseEvent e) {
        /* Clique do mouse desligado
        int x = e.getX();
        int y = e.getY();

        this.setTitle("X: " + x + ", Y: " + y
                + " -> Cell: " + (y / Consts.CELL_SIDE) + ", " + (x / Consts.CELL_SIDE));

        this.hero.getPosicao().setPosicao(y / Consts.CELL_SIDE, x / Consts.CELL_SIDE);

        repaint();
        */
    }


    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("POO2023-1 - Skooter");
        setAlwaysOnTop(true);
        setAutoRequestFocus(false);
        setResizable(false);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 561, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 500, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents
    // Variables declaration - do not modify//GEN-BEGIN:variables
    // End of variables declaration//GEN-END:variables

    public void mouseMoved(MouseEvent e) {
    }

    public void mouseClicked(MouseEvent e) {
    }

    public void mouseReleased(MouseEvent e) {
    }

    public void mouseEntered(MouseEvent e) {
    }

    public void mouseExited(MouseEvent e) {
    }

    public void mouseDragged(MouseEvent e) {
    }

    public void keyTyped(KeyEvent e) {
    }

    public void keyReleased(KeyEvent e) {
    }
    
    
    
}
