package Controler;

import Modelo.Chaser;
import Modelo.Personagem;
import Modelo.Parede;
import Modelo.Hero;
import Modelo.Battery;
import Modelo.Bolt;
import Modelo.ParedeAmarela;
import Modelo.Bomb;
import Modelo.Explosao;
import Modelo.Bullet;
import Modelo.Cadeado;
import Modelo.Chave;
import Modelo.Portal;
import Modelo.Dust;
import Modelo.LancaChamas;
import Modelo.Fogo;
import Modelo.SaidaFase;
import auxiliar.Posicao;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

public class ControleDeJogo {
    private Tela tela;

    public ControleDeJogo(Tela tela) {
        this.tela = tela;
    }
    
    
    public void desenhaTudo(ArrayList<Personagem> e) {
        for (int i = 0; i < e.size(); i++) {
            e.get(i).autoDesenho();
        }
    }
    
    public void processaTudo(ArrayList<Personagem> umaFase) {
        Hero hero = (Hero) umaFase.get(0);
        Personagem pIesimoPersonagem;
        for (int i = 1; i < umaFase.size(); i++) {
            pIesimoPersonagem = umaFase.get(i);
            
            atirar(hero,pIesimoPersonagem); //funcao que faz o heroi atirar
            coletar(hero,pIesimoPersonagem,umaFase); // funcao que faz o heroi coletar itens
            movimentacaoChaser(hero,pIesimoPersonagem); // funcao que detecta o chaser
            seEncostarMorre(hero,pIesimoPersonagem,umaFase); //funcao que verifica se o heroi enconstou em algo que o mata
            mortePersonagem(pIesimoPersonagem,umaFase); //funcao que verifica se o personagem morreu, e caso sim realiza a animacao
            lancaChamas(hero,pIesimoPersonagem,umaFase); //funcao que faz sair e entrar fogo do lancachamas
            verificaSaida(hero,pIesimoPersonagem,umaFase); //funcao que verifica se a saida esta aberta
        }
        /*para que o codigo das acoes do heroi sejam chamados uma vez por frame e nao pelo numero de vezes equivalente ao tamanho do for, 
        esses metodos foram tirados do laço for */
        if (hero.isMorrendo())
            morteHeroi(hero,umaFase); //funcao que verifica se o heroi morreu
        if (hero.isTeleporteInicio())
            animacaoTeleporteInicio(hero,umaFase); //funcao que verifica se o personagem esta teleportando
        if (hero.isTeleporteFim())
            animacaoTeleporteFim(hero,umaFase);
    }
    

    /*Retorna true se a posicao pHero é válida para Hero com relacao a todos os personagens no array*/
    public boolean ehPosicaoValida(ArrayList<Personagem> umaFase, Hero hero, Posicao pHero) {
        Personagem pIesimoPersonagem;
        for (int i = 1; i < umaFase.size(); i++) {
            pIesimoPersonagem = umaFase.get(i);
            //caso for uma parede amarela ou uma bomba, ela devera ser empurrada
            if (pIesimoPersonagem instanceof ParedeAmarela || pIesimoPersonagem instanceof Bomb) {
                Posicao pPersonagem = pIesimoPersonagem.getPosicao();
                //caso a parede atenda todas as condicoes, ela sera empurrada, caso contrario nao sera empurrada 
                if (pIesimoPersonagem.getPosicao().igual(pHero)) {
                    if ("down".equals(hero.getDirection()) && !HaPersonagemAbaixo(pPersonagem,umaFase)) {
                        pIesimoPersonagem.moveDown();
                        return true;
                    }
                    else if ("up".equals(hero.getDirection()) && !HaPersonagemAcima(pPersonagem,umaFase)) {
                        pIesimoPersonagem.moveUp();
                        return true;
                    }
                    else if ("right".equals(hero.getDirection()) && !HaPersonagemNaDireita(pPersonagem,umaFase)) {
                        pIesimoPersonagem.moveRight();
                        return true;
                    }  
                    else if ("left".equals(hero.getDirection()) && !HaPersonagemNaEsquerda(pPersonagem,umaFase)) {
                        pIesimoPersonagem.moveLeft();
                        return true;
                    }
                    else {
                        return false;
                    }
                }  
            }
           //caso for qualquer outro objeto nao transponivel ela nao sera empurrada
            else if (!pIesimoPersonagem.isbTransponivel()) {
                if (pIesimoPersonagem.getPosicao().igual(pHero)) {
                      
                    if (pIesimoPersonagem instanceof Portal) {   
                        hero.voltaAUltimaPosicao();
                        hero.setTeleporteInicio(true);
                    }
                    else if (pIesimoPersonagem instanceof Cadeado && hero.getnChaves() > 0) {
                        umaFase.remove(pIesimoPersonagem);
                        hero.setnChaves(hero.getnChaves()-1);
                        System.out.println("Numero de chaves obtidas: " + hero.getnChaves());
                        return false;
                    }
                    else  {
                        return false; //retorna falso, pois o personagem vai voltar uma posicao pra tras
                    }
                }   
            }
                 
        }
        return true; //retorna true pois o personagem vai seguir a posicao que o player mandar
    }
    
    
    public boolean ColisaoBala(ArrayList<Personagem> umaFase, Bullet bala, Posicao pBala) {
        
        //deleta a bala caso ela ultrapasse a camera
        if (bala.getPosicao().getLinha() < tela.getCameraLinha() ||
            bala.getPosicao().getLinha() > tela.getCameraLinha()+15) {
            umaFase.remove(bala);
            return false;
        }
        
        for (int i = 1; i < umaFase.size(); i++) {
            Personagem pIesimoPersonagem = umaFase.get(i);   
           
            if (pIesimoPersonagem instanceof Bomb) { //verifica se a bala atinge alguma bomba
                if (pIesimoPersonagem.getPosicao().igual(pBala)) {
                    umaFase.remove(bala); 
                    Set<Posicao> bombasExplodidas = new HashSet<>();
                    Bomb b = (Bomb) pIesimoPersonagem;
                    explosao(b,umaFase,bombasExplodidas);
                    return false;
                }
            }
            else if(pIesimoPersonagem instanceof Dust || pIesimoPersonagem instanceof Chaser) {
                if (pIesimoPersonagem.getPosicao().igual(pBala)) {
                    umaFase.remove(bala); 
                    pIesimoPersonagem.setMorrendo(true);
                    return false;
                }
            }
            else if (!pIesimoPersonagem.isbTransponivel()) { //verifica se a bala atinge alguma parede
                if (pIesimoPersonagem.getPosicao().igual(pBala)) {
                    umaFase.remove(bala); //caso a posicao da bala seja a mesma da parede, deleta a bala do cenario
                    return false;
                }
            }
             
        }
        return true;
    }
    
    //funcao que verifica se o tiro inicial do heroi esta dentro de uma parede ou de uma bomba
    public boolean PosicaoInicialBala(ArrayList<Personagem> umaFase, Hero hero) {
        Personagem pIesimoPersonagem;
        int linhaHeroi = hero.getPosicao().getLinha() ;
        int colunaHeroi = hero.getPosicao().getColuna();
        
        for (int i = 1; i < umaFase.size(); i++) {
            
            pIesimoPersonagem = umaFase.get(i);
            int linhaP = pIesimoPersonagem.getPosicao().getLinha();
            int colunaP = pIesimoPersonagem.getPosicao().getColuna();
            
            if (   ("down".equals(hero.getDirection()) && linhaP == linhaHeroi+1 && colunaP == colunaHeroi) || 
                   ("up".equals(hero.getDirection()) && linhaP == linhaHeroi-1 && colunaP == colunaHeroi) ||
                   ("right".equals(hero.getDirection()) && linhaP == linhaHeroi && colunaP == colunaHeroi+1) ||
                   ("left".equals(hero.getDirection()) && linhaP == linhaHeroi && colunaP == colunaHeroi-1)) {
            
                
                //verifica se a bala vai spawnar em alguma bomba
                if (pIesimoPersonagem instanceof Bomb) {
                    Bomb b = (Bomb) pIesimoPersonagem;
                    Set<Posicao> bombasExplodidas = new HashSet<>();
                    explosao(b,umaFase,bombasExplodidas);
                    return false;
                }
                //verifica se a bala vai spawnar em uma poeira ou chaser
                else if (pIesimoPersonagem instanceof Dust || pIesimoPersonagem instanceof Chaser) {
                    pIesimoPersonagem.setMorrendo(true);
                    return false;
                }
                
                //verifica se a bala vai spawnar em alguma parede
                else if (!pIesimoPersonagem.isbTransponivel()) {
                    return false;
                }

            }
            
        }
        return true;
    }
    
    
    public void coletar(Hero hero, Personagem pIesimoPersonagem,ArrayList<Personagem> umaFase) {
        if (hero.getPosicao().igual(pIesimoPersonagem.getPosicao())) {
            if (pIesimoPersonagem.isbTransponivel() && !pIesimoPersonagem.isbMortal()) /*TO-DO: verificar se o personagem eh  antes de retirar*/ {
                if (pIesimoPersonagem instanceof Battery){
                    hero.setnBaterias(hero.getnBaterias()+9);
                }
                if (pIesimoPersonagem instanceof Bolt) {
                    hero.setnBolts(hero.getnBolts() - 1);
                    System.out.println("Numero de bolts restantes: "+ hero.getnBolts());
                }
                if(pIesimoPersonagem instanceof Chave) {
                    hero.setnChaves(hero.getnChaves()+1);
                    System.out.println("Numero de chaves obtidas: " + hero.getnChaves());
                }
                umaFase.remove(pIesimoPersonagem);
            }
        }
    }
    
    
    public void movimentacaoChaser(Hero hero, Personagem pIesimoPersonagem) {
        if (pIesimoPersonagem instanceof Chaser) {
            Chaser chaser = (Chaser) pIesimoPersonagem;
            chaser.computeDirection(hero.getPosicao());
        }
    }
 
    public void atirar(Hero hero, Personagem pIesimoPersonagem) {
        if (pIesimoPersonagem instanceof Bullet) {
            ((Bullet) pIesimoPersonagem).direcaoBullet(hero); //ativa a funcao da direcao do tiro
        }
    }
    
    public void seEncostarMorre(Hero hero,Personagem pIesimoPersonagem,ArrayList<Personagem> umaFase) {
        if (pIesimoPersonagem.isbMortal() && hero.getPosicao().igual(pIesimoPersonagem.getPosicao())) {
            hero.setMorrendo(true);
            umaFase.remove(pIesimoPersonagem);   
        } 
    }
    
    
    public void explosao (Bomb b,ArrayList<Personagem> umaFase,Set<Posicao> bombasExplodidas) {
        Posicao pBomba = b.getPosicao(); 
        umaFase.remove(b);
        
        if (bombasExplodidas.contains(pBomba)) { //hashset para evitar overflow
                return;
        }
        bombasExplodidas.add(pBomba);
        
        //verifica os espacos vazios ao redor da bomba e ajeita as explosoes nos lugares.
        b.explosao(0).getPosicao().copia(pBomba);
        b.explosao(0).setMorrendo(true); 
       
        if (!HaPersonagemAcima(pBomba,umaFase)) {
            b.explosao(1).setPosicao(pBomba.getLinha()-1, pBomba.getColuna());
            b.explosao(1).setMorrendo(true);               
        }
        if (!HaPersonagemAbaixo(pBomba,umaFase)) {
            b.explosao(2).setPosicao(pBomba.getLinha()+1, pBomba.getColuna());
            b.explosao(2).setMorrendo(true);   
        }
        if (!HaPersonagemNaEsquerda(pBomba,umaFase)) {
            b.explosao(3).setPosicao(pBomba.getLinha(), pBomba.getColuna()-1);
            b.explosao(3).setMorrendo(true); 
        }
        if (!HaPersonagemNaDireita(pBomba,umaFase)) {
            b.explosao(4).setPosicao(pBomba.getLinha(), pBomba.getColuna()+1);
            b.explosao(4).setMorrendo(true); 
        }
        if (!HaPersonagemDiagonalSE(pBomba,umaFase)) {
            b.explosao(5).setPosicao(pBomba.getLinha()-1, pBomba.getColuna()-1);
            b.explosao(5).setMorrendo(true);    
        }
        if (!HaPersonagemDiagonalSD(pBomba,umaFase)) {
            b.explosao(6).setPosicao(pBomba.getLinha()-1, pBomba.getColuna()+1);
            b.explosao(6).setMorrendo(true); 
        }
        if (!HaPersonagemDiagonalIE(pBomba,umaFase)) {
            b.explosao(7).setPosicao(pBomba.getLinha()+1, pBomba.getColuna()-1);
            b.explosao(7).setMorrendo(true); 
        }
        if (!HaPersonagemDiagonalID(pBomba,umaFase)) {
            b.explosao(8).setPosicao(pBomba.getLinha()+1, pBomba.getColuna()+1);
            b.explosao(8).setMorrendo(true); 
        }
        
        //agora verifica se ha algum tipo de personagem em volta da bomba, e dependendo de qual ele morrera
        for (int i = umaFase.size()-1; i >= 0; i--) { //EM ORDEM DECRESCENTE POIS O HEROI DEVE SER O ULTIMO A MORRER
            Personagem pIesimoPersonagem = umaFase.get(i);
            int linPersonagem = pIesimoPersonagem.getPosicao().getLinha();
            int colPersonagem = pIesimoPersonagem.getPosicao().getColuna();
            
            if (    (linPersonagem == pBomba.getLinha() && colPersonagem == pBomba.getColuna()) ||
                    (linPersonagem == pBomba.getLinha()+1 && colPersonagem == pBomba.getColuna()) ||
                    (linPersonagem == pBomba.getLinha()-1 && colPersonagem == pBomba.getColuna()) ||   
                    (linPersonagem == pBomba.getLinha() && colPersonagem == pBomba.getColuna()+1) ||
                    (linPersonagem == pBomba.getLinha() && colPersonagem == pBomba.getColuna()-1) ||
                    (linPersonagem == pBomba.getLinha()+1 && colPersonagem == pBomba.getColuna()+1) ||
                    (linPersonagem == pBomba.getLinha()+1 && colPersonagem == pBomba.getColuna()-1) ||   
                    (linPersonagem == pBomba.getLinha()-1 && colPersonagem == pBomba.getColuna()-1) ||
                    (linPersonagem == pBomba.getLinha()-1 && colPersonagem == pBomba.getColuna()+1)) {
                
                
                //se houver outra bomba ao redor, detona ela
                if (pIesimoPersonagem instanceof Bomb) {
                    Bomb novaBomba = (Bomb) pIesimoPersonagem;
                    explosao(novaBomba, umaFase, bombasExplodidas); // chamada nova
                }
                //detona os demais personagens ao redor da bomba
                if (pIesimoPersonagem instanceof ParedeAmarela || pIesimoPersonagem instanceof Hero || pIesimoPersonagem.isbTransponivel() || pIesimoPersonagem instanceof Chaser) {
                    pIesimoPersonagem.setMorrendo(true);  
                }
            }
        }
    }
    
     public void passouDeFase(Hero hero,ArrayList<Personagem> umaFase) {
        umaFase.clear();
        hero.setMorrendo(false);
        hero.importIcon("robbo_front.png");
        hero.setnBaterias(0);
        hero.setnChaves(0);
        hero.setTempoMorte(10);
        hero.setFase(hero.getFase()+1);
        
        if (hero.getFase() == 2) {
            hero.setnBolts(10);
            Fase fase2 = new Fase2();
            ArrayList<Personagem> novaFase = fase2.carregarFase(hero);
            umaFase.addAll(novaFase);
        }
        /*
        else if (hero.getFase() == 3) {
                Fase3 fase3 = new Fase3();
                ArrayList<Personagem> novaFase = fase3.carregarFase(hero);
                umaFase.addAll(novaFase);
            }
            else if (hero.getFase() == 4) {
                Fase4 fase4 = new Fase4();
                ArrayList<Personagem> novaFase = fase4.carregarFase(hero);
                umaFase.addAll(novaFase);
            }
            else if (hero.getFase() == 5) {
                Fase5 fase5 = new Fase5();
                ArrayList<Personagem> novaFase = fase5.carregarFase(hero);
                umaFase.addAll(novaFase);
            }
        
        */
        tela.atualizaCamera();
     }
     
     public void verificaSaida(Hero hero, Personagem pIesimoPersonagem,ArrayList<Personagem> umaFase) {
        if (pIesimoPersonagem instanceof SaidaFase) {
            if (hero.getnBolts() == 0) {
                pIesimoPersonagem.setbTransponivel(true);
                pIesimoPersonagem.importIcon("saida_aberta.png");
                
                if (hero.getPosicao().igual(pIesimoPersonagem.getPosicao())) 
                    passouDeFase(hero,umaFase);     
            }
        }
    }
    
    public void reseta(Hero hero,ArrayList<Personagem> umaFase) {
        umaFase.clear();
        hero.importIcon("robbo_front.png");
        hero.setnBaterias(0);
        hero.setnBolts(9);
        hero.setnChaves(0);
        hero.setMorrendo(false);
        hero.setTempoMorte(10);
        
        if (hero.getnVidas() > 0) {
            hero.setnVidas(hero.getnVidas()-1);
            
            if (hero.getFase() == 1) {
                Fase fase1 = new Fase1();
                ArrayList<Personagem> novaFase = fase1.carregarFase(hero);
                umaFase.addAll(novaFase);
                
            }
            
            else if (hero.getFase() == 2) {
                hero.setnBolts(10);
                Fase2 fase2 = new Fase2();
                ArrayList<Personagem> novaFase = fase2.carregarFase(hero);
                umaFase.addAll(novaFase);
            }
            /*
            else if (hero.getFase() == 3) {
                hero.setnBolts(10);
                Fase3 fase3 = new Fase3();
                ArrayList<Personagem> novaFase = fase3.carregarFase(hero);
                umaFase.addAll(novaFase);
            }
            else if (hero.getFase() == 4) {
                hero.setnBolts(10);
                Fase4 fase4 = new Fase4();
                ArrayList<Personagem> novaFase = fase4.carregarFase(hero);
                umaFase.addAll(novaFase);
            }
            else if (hero.getFase() == 5) {
                hero.setnBolts(10);
                Fase5 fase5 = new Fase5();
                ArrayList<Personagem> novaFase = fase5.carregarFase(hero);
                umaFase.addAll(novaFase);
            }
            */
            
        }
        else {
            hero.setFase(1);
            Fase1 fase1 = new Fase1();
            ArrayList<Personagem> novaFase = fase1.carregarFase(hero);
            umaFase.addAll(novaFase);
        }
        tela.atualizaCamera();
    }
    
    
    public void mortePersonagem(Personagem personagem,ArrayList<Personagem> umaFase) { 
        if (personagem.isMorrendo() == true) {    
            
            if (personagem.getTempoMorte() == 10) 
                personagem.importIcon("explosion1.png");
            if (personagem.getTempoMorte() == 6) 
                personagem.importIcon("explosion2.png");
            if (personagem.getTempoMorte() == 3) 
                personagem.importIcon("explosion3.png");
            
            personagem.setTempoMorte(personagem.getTempoMorte()-1);
            if (personagem.getTempoMorte() <= 0) {
                umaFase.remove(personagem);
            }
        }
              
    }
    
    public void morteHeroi (Hero hero,ArrayList<Personagem> umaFase) {
        if (hero.isMorrendo() == true) {
            
            if (hero.getTempoMorte() == 10) 
                hero.importIcon("explosion1.png");
            if (hero.getTempoMorte() == 6) 
                hero.importIcon("explosion2.png");
            if (hero.getTempoMorte() == 3) 
                hero.importIcon("explosion3.png");
            
            hero.setTempoMorte(hero.getTempoMorte()-1);
            if (hero.getTempoMorte() <= 0) {
                reseta(hero,umaFase);
            }
        }  
    }
   
    
    public void teleporte(Hero hero, ArrayList<Personagem> umaFase) {
        
        Portal portalA = null;
        Posicao pHero = hero.getPosicao();
        //encontra o portal que o robo interagiu primeiro
        for (int i=0; i<umaFase.size();i++) {
            if (umaFase.get(i) instanceof Portal) {
                portalA = (Portal) umaFase.get(i);
                Posicao pPortalA = portalA.getPosicao();
                if ("down".equals(hero.getDirection()) && pPortalA.getLinha() == pHero.getLinha()+1 && pPortalA.getColuna() == pHero.getColuna()) 
                    break; 
                else if ("up".equals(hero.getDirection()) && pPortalA.getLinha() == pHero.getLinha()-1 && pPortalA.getColuna() == pHero.getColuna()) 
                    break;
                else if ("left".equals(hero.getDirection()) && pPortalA.getLinha() == pHero.getLinha() && pPortalA.getColuna() == pHero.getColuna()-1) 
                    break;
                else if ("right".equals(hero.getDirection()) && pPortalA.getLinha() == pHero.getLinha() && pPortalA.getColuna() == pHero.getColuna()+1) 
                    break; 
            }   
        }
        //encontra qual portal esta conectado com o que o robo interagiu, e teleporta o robo para este portal
        for (int i=0; i<umaFase.size();i++){
            if (umaFase.get(i) instanceof Portal && portalA != null) {
                Portal portalB = (Portal) umaFase.get(i);

                if(portalA.getnConexao() == portalB.getnPortal()) {
                    Posicao pPortalB = portalB.getPosicao();
                    if ("down".equals(hero.getDirection())) 
                        pHero.setPosicao(pPortalB.getLinha()+1,pPortalB.getColuna());
                    else if ("up".equals(hero.getDirection())) 
                        pHero.setPosicao(pPortalB.getLinha()-1,pPortalB.getColuna());
                    else if ("right".equals(hero.getDirection())) 
                        pHero.setPosicao(pPortalB.getLinha(),pPortalB.getColuna()+1);
                    else if ("left".equals(hero.getDirection())) 
                        pHero.setPosicao(pPortalB.getLinha(),pPortalB.getColuna()-1);
                }
            }    
        }
        tela.atualizaCamera();
        hero.setTeleporteInicio(false);
        hero.setTempoTeleporte(10);
        hero.setTeleporteFim(true);
    }
    
    public void animacaoTeleporteInicio(Hero hero,ArrayList<Personagem> umaFase) {
        if (hero.isTeleporteInicio() == true) {    
            
            if (hero.getTempoTeleporte() == 10) 
                hero.importIcon("explosion1.png");
            if (hero.getTempoTeleporte() == 6) 
                hero.importIcon("explosion2.png");  
            if (hero.getTempoTeleporte() == 3) 
                hero.importIcon("explosion3.png");
           
            hero.setTempoTeleporte(hero.getTempoTeleporte()-1);
           
            if (hero.getTempoTeleporte() <= 0) {
                teleporte(hero,umaFase);
            }
        }
    }
    public void animacaoTeleporteFim(Hero hero, ArrayList<Personagem> umaFase) {
        if (hero.isTeleporteFim() == true) {
            
            if (hero.getTempoTeleporte() == 10) 
                hero.importIcon("explosion1.png");
            if (hero.getTempoTeleporte() == 6) 
                hero.importIcon("explosion2.png");
            if (hero.getTempoTeleporte() == 3) 
                hero.importIcon("explosion3.png");
            
            hero.setTempoTeleporte(hero.getTempoTeleporte()-1);
            
            if (hero.getTempoTeleporte() <= 0) {
                hero.importIcon("robbo_front.png");
                hero.setTeleporteFim(false);
                hero.setTempoTeleporte(10);
            }
        }
    }
    
    public void lancaChamas(Hero hero,Personagem pIesimoPersonagem, ArrayList<Personagem> umaFase) {
        if (pIesimoPersonagem instanceof LancaChamas) {
            LancaChamas lc = (LancaChamas) pIesimoPersonagem;
            if (lc.isSaindo()) {
                SaindoFogo(hero,lc,umaFase);
            }
            if (lc.isEntrando()) {
                EntrandoFogo(lc,umaFase);
            }
        }
    }
    
    public void SaindoFogo(Hero hero,LancaChamas lc, ArrayList<Personagem> umaFase) {
        Posicao pLc = lc.getPosicao();
        Fogo f = null;
        Posicao pF = null;
        int nFogo = -1;
        
        for (int i=0; i<lc.nFogos();i++) {
            //faz uma verificacao se o fogo nao esta ativo, se nao coloque ele na posicao
            if (!lc.fogo(i).isAtivo()) {
                f = lc.fogo(i);
                pF = lc.fogo(i).getPosicao();
                nFogo = i+1;
                break;
            }
        }
        //se nao for encontrado nenhum fogo, significa que todos estao ativos, por isso para de sair fogo e comeca a animacao de entrar
        if (f == null) {
            lc.setSaindo(false);
            lc.setEntrando(true);
        }
        
        //caso nao haja nada na posicao onde o primeiro fogo vai spawnar ao redor do lancachamas
        else if (("up".equals(lc.getDirection()) && !HaPersonagemAcima(pLc,umaFase)) ||
                ("down".equals(lc.getDirection()) && !HaPersonagemAbaixo(pLc,umaFase)) ||
                ("left".equals(lc.getDirection()) && !HaPersonagemNaEsquerda(pLc,umaFase)) ||
                ("right".equals(lc.getDirection()) && !HaPersonagemNaDireita(pLc,umaFase))) {
            
            if (f.getTempoSpawn() <= 100) {
                f.setTempoSpawn(f.getTempoSpawn()+1);
            }
            
            else {
                //verifica se o heroi esta aonde sai o primeiro fogo do lanca chamas, se sim ele morre
                if (hero.getPosicao().igual(proximaPosicao(pLc,lc.getDirection()))) {
                    lc.setSaindo(false);
                    hero.setMorrendo(true);
                }
                else {
                    f.setAtivo(true);
                    f.setTempoSpawn(0);
                    f.getPosicao().copia(proximaPosicao(pLc, lc.getDirection()));
                    if ("up".equals(lc.getDirection()) || "down".equals(lc.getDirection()))
                        f.importIcon("fire1.png");
                    else
                        f.importIcon("fire3.png");
                }
            }
        }
        
       
        //caso ja tenha saido o primeiro fogo do lanca chamas, verifica onde o proximo fogo sera colocado
        else  {
            f.setPosicao(pLc.getLinha(),pLc.getColuna());
            while (HaFogoNaProximaPosicao(pF,lc.getDirection(),umaFase)) {
                f.getPosicao().copia(proximaPosicao(pF,lc.getDirection()));
            }
            
            //caso o heroi esteja na frente do proximo fogo
            if (hero.getPosicao().igual(proximaPosicao(pF,lc.getDirection()))) {
                lc.setSaindo(false);
                hero.setMorrendo(true);
            }
            
            //se tiver um personagem na frente cancela a animacao de sair fogo e inicia a de entrar
            else if (("up".equals(lc.getDirection()) && HaPersonagemAcima(pF,umaFase)) ||
                    ("down".equals(lc.getDirection()) && HaPersonagemAbaixo(pF,umaFase)) ||
                    ("left".equals(lc.getDirection()) && HaPersonagemNaEsquerda(pF,umaFase)) ||
                    ("right".equals(lc.getDirection()) && HaPersonagemNaDireita(pF,umaFase))) {
                lc.setSaindo(false);
                lc.setEntrando(true);
            }
            
            //se nao tiver nenhum personagem na frente, coloca um delay de spawn antes de o colocar
            else {    
                if (f.getTempoSpawn() < 1) {
                    f.setTempoSpawn(f.getTempoSpawn()+1);
                    
                }
                else {
                    f.setAtivo(true);
                    f.setTempoSpawn(0);
                    f.getPosicao().copia(proximaPosicao(pF,lc.getDirection()));
                    if ("up".equals(lc.getDirection()) || "down".equals(lc.getDirection()) ) {
                        if (nFogo%2 == 0) 
                            f.importIcon("fire2.png");
                        else
                            f.importIcon("fire1.png");
                    }
                    else {
                        if (nFogo%2 == 0) 
                            f.importIcon("fire4.png");
                        else
                            f.importIcon("fire3.png");
                    }
                }
            }
         
        }    
    }
    
    public void EntrandoFogo (LancaChamas lc, ArrayList<Personagem> umaFase) {
        Fogo f = null;
        Posicao pF = null;
        int nFogo = -1;
        for (int i = lc.nFogos()-1; i>=0; i--) {
           if (lc.fogo(i).getPosicao().getLinha() != 0 && lc.fogo(i).getPosicao().getColuna() != 0) {
                f = lc.fogo(i);
                pF = lc.fogo(i).getPosicao();
                nFogo = i+1;
                break;
           }
        }
        if (nFogo == -1) {
            lc.setEntrando(false);
            lc.setSaindo(true);
        }
        else {
            if (f.getTempoSpawn() < 1) {
                f.setTempoSpawn(f.getTempoSpawn()+1);
            }
            else {
                f.importIcon("transparente.png");
                f.setAtivo(false);
                f.setPosicao(0, 0);
                f.setTempoSpawn(0);
            }
        }
    }
    
    
    //funcoes que verificam se ha personagens ao redor de outro
    public boolean HaPersonagemAbaixo (Posicao p,ArrayList<Personagem> umaFase) {
        for (int i = 1; i < umaFase.size(); i++) {
            if (umaFase.get(i).getPosicao().getLinha() == p.getLinha()+1
                && umaFase.get(i).getPosicao().getColuna() == p.getColuna()) {
                return true;
            }
        }
        return false;
    }
    
    public boolean HaPersonagemAcima (Posicao p,ArrayList<Personagem> umaFase) {
        for (int i = 1; i < umaFase.size(); i++) {
            if (umaFase.get(i).getPosicao().getLinha() == p.getLinha()-1
                && umaFase.get(i).getPosicao().getColuna() == p.getColuna()) {
                return true;
            }
        }
        return false;
    }
    
    public boolean HaPersonagemNaDireita (Posicao p,ArrayList<Personagem> umaFase) {
        for (int i = 1; i < umaFase.size(); i++) {
            if (umaFase.get(i).getPosicao().getLinha() == p.getLinha()
                && umaFase.get(i).getPosicao().getColuna() == p.getColuna()+1) {
                return true;
            }
        }
        return false;
    }
    
    public boolean HaPersonagemNaEsquerda (Posicao p,ArrayList<Personagem> umaFase) {
        for (int i = 1; i < umaFase.size(); i++) {
            if (umaFase.get(i).getPosicao().getLinha() == p.getLinha()
                && umaFase.get(i).getPosicao().getColuna() == p.getColuna()-1) {
                return true;
            }
        }
        return false;
    }
    
    public boolean HaPersonagemDiagonalSE (Posicao p,ArrayList<Personagem> umaFase) {
        for (int i = 1; i < umaFase.size(); i++) {
            if (umaFase.get(i).getPosicao().getLinha() == p.getLinha()-1
                && umaFase.get(i).getPosicao().getColuna() == p.getColuna()-1) {
                return true;
            }
        }
        return false;  
    }
    
    public boolean HaPersonagemDiagonalSD (Posicao p,ArrayList<Personagem> umaFase) {
        for (int i = 1; i < umaFase.size(); i++) {
            if (umaFase.get(i).getPosicao().getLinha() == p.getLinha()-1
                && umaFase.get(i).getPosicao().getColuna() == p.getColuna()+1) {
                return true;
            }
        }
        return false;  
    }
    
    public boolean HaPersonagemDiagonalIE (Posicao p,ArrayList<Personagem> umaFase) {
        for (int i = 1; i < umaFase.size(); i++) {
            if (umaFase.get(i).getPosicao().getLinha() == p.getLinha()+1
                && umaFase.get(i).getPosicao().getColuna() == p.getColuna()-1) {
                return true;
            }
        }
        return false;  
    }
    
    public boolean HaPersonagemDiagonalID (Posicao p,ArrayList<Personagem> umaFase) {
        for (int i = 1; i < umaFase.size(); i++) {
            if (umaFase.get(i).getPosicao().getLinha() == p.getLinha()+1
                && umaFase.get(i).getPosicao().getColuna() == p.getColuna()+1) {
                return true;
            }
        }
        return false;
    }
    
    public boolean HaFogoNaProximaPosicao(Posicao p, String direcao, ArrayList<Personagem> umaFase) {
       Posicao proxP = proximaPosicao(p,direcao);
        for (int i = 1; i < umaFase.size(); i++) {
            if (proxP.igual(umaFase.get(i).getPosicao()) && umaFase.get(i) instanceof Fogo) {
                return true;
            }
        }
        return false;
    }
    
    public Posicao proximaPosicao(Posicao atual, String direcao) {
        switch (direcao) {
            case "up": return new Posicao(atual.getLinha() - 1, atual.getColuna());
            case "down": return new Posicao(atual.getLinha() + 1, atual.getColuna());
            case "left": return new Posicao(atual.getLinha(), atual.getColuna() - 1);
            case "right": return new Posicao(atual.getLinha(), atual.getColuna() + 1);
            default: return atual;
        }
}
    
}
