/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

/**
 *
 * @author bedos
 */
public class Portal extends Personagem {
    private int nPortal;
    private int nConexao;
    
    public Portal(String sNomeImagePNG, int nPortal, int nConexao) {
        super(sNomeImagePNG);
        this.nPortal = nPortal;
        this.nConexao = nConexao;
        this.bMortal = false;
        this.bTransponivel = false;
    }

    public int getnPortal() {
        return nPortal;
    }

    public void setnPortal(int nPortal) {
        this.nPortal = nPortal;
    }

    public int getnConexao() {
        return nConexao;
    }

    public void setnConexao(int nConexao) {
        this.nConexao = nConexao;
    }
    
    
    
    
    
    
    
}
